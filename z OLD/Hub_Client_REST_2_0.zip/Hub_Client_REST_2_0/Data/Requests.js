var requests = ["R01|Housing|2001 Census Housing|24UE", 
	"wibble|||00HN"]