function activateDataSlider(evt) {
	if (evt.type == "mousedown") {
		dataSliderActive = true
	}
	
	if (evt.type == "mouseup") {
		dataSliderActive = false
	}	
}

function checkDataVariable(areaName) {
	
	if (areaName.indexOf("..") > -1) {
		var isShortened = true
		areaName = areaName.replace("..","")
	} else {
		var isShortened = false	
	}
	
	for (i=0; i<currentDetails.length; i++) {
		var theName = currentDetails[i].split("|")[0]
		
		//Remove any commas
		theName = theName.replace(",","")

		// Check if the name has been shortened
		if (isShortened) {
			if (theName.indexOf(areaName) > -1) {
				break
			}
		} else {
			if (theName == areaName) {
				break
			}
		}
	}

	
	if (i > dataRows) {
		//alert(dataStartPos)
		dataStartPos += i
		buildDataTable();
		//alert(dataStartPos)
	}
}

function dataDownArrow(evt) {
	if (dataSliderPos >= (dataRows/2)-1) {
		dataSliderPos = dataRows/2-1
		return
	}
	dataSliderPos++
	newPos = dataSliderPos * dataSliderSize	
	
	if (dataSliderPos == (dataRows/2)-1) {
		newPos = dataSliderMax
	}
	
	var theValue =  'translate(0 ' + newPos + ')';
	svgDataDoc.getElementById("sliderBox").setAttribute('transform', theValue);
	
	var numIncrements = parseInt(dataSliderMax/dataSliderSize)
	dataStartPos +=parseInt((currentDetails.length-dataRows)/numIncrements) 

	if (dataStartPos > currentDetails.length) {
		dataStartPos = currentDetails.length	
	}
	buildDataTable();
}


function dataUpArrow(evt) {
	if (dataSliderPos <= 0) {
		dataSliderPos = 0
		return
	}
	dataSliderPos--
	newPos = (dataSliderPos * dataSliderSize)
	
	if (dataSliderPos == 0) {
		newPos = dataSliderMin
		dataStartPos = dataRows
	}
	var theValue =  'translate(0 ' + newPos + ')';
	svgDataDoc.getElementById("sliderBox").setAttribute('transform', theValue);
	
	var numIncrements = parseInt(dataSliderMax/dataSliderSize)
	dataStartPos -=parseInt((currentDetails.length-dataRows)/numIncrements) 

	if (dataStartPos < dataRows) {
		dataStartPos = dataRows
	}
	buildDataTable()
}


function stopDataSlider(evt) {
		newPos = dataSliderPos * dataSliderSize
		var theValue =  'translate(0 ' + newPos + ')';
		svgDataDoc.getElementById("sliderBox").setAttribute('transform', theValue);
}


function moveDataSlider(evt) {
	
	if (dataSliderActive == false) {
		return
	}

	var prevSliderPos = dataSliderPos
	var currValue = evt.getClientY - dataSliderSize - dataTableOffset

	
	if (currValue < dataSliderMin) {
		currValue = dataSliderMin
	}
	
	if (currValue > dataSliderMax) {
		currValue = dataSliderMax
	}
	
	dataSliderPos = currValue/dataSliderSize
	
	var theValue =  'translate(0 ' + parseInt(currValue) + ')';
	svgDataDoc.getElementById("sliderBox").setAttribute('transform', theValue);	
	
	dataSliderPos = parseInt(dataSliderPos)
	if (dataSliderPos == 0) {
		currValue = dataSliderMin
	}
	
	var numIncrements = parseInt(dataSliderMax/dataSliderSize)

	if (dataSliderPos >= numIncrements) {
		currValue = dataSliderMax
		dataSliderPos = numIncrements
	}

	checkDataSliderPos(prevSliderPos)
	buildDataTable()

}

function clickDataSlider(evt) {

	var numIncrements = parseInt(dataSliderMax/dataSliderSize)
	var prevSliderPos = dataSliderPos
	var currValue = evt.getClientY - dataTableOffset
	
	dataSliderPos = parseInt(currValue/dataSliderSize)
	
	if (dataSliderPos == 0) {
		currValue = dataSliderMin
	}
	
	if (dataSliderPos >= numIncrements) {
		currValue = dataSliderMax
		dataSliderPos = numIncrements
	}
	var theValue =  'translate(0 ' + currValue + ')';
	svgDataDoc.getElementById("sliderBox").setAttribute('transform', theValue);
	
	checkDataSliderPos(prevSliderPos)
	buildDataTable()
}



function checkDataSliderPos(prevSliderPos) {
	var numIncrements = parseInt(dataSliderMax/dataSliderSize)

	if (dataSliderPos < prevSliderPos) {
		dataStartPos -=parseInt((currentDetails.length-dataRows)/numIncrements)*(prevSliderPos-dataSliderPos)
		
		if ((dataStartPos < dataRows) || (dataSliderPos == 0)){
			dataStartPos = dataRows	
		}
	} else {
		dataStartPos +=parseInt((currentDetails.length-dataRows)/numIncrements)*(dataSliderPos-prevSliderPos)
		
		if (dataStartPos > currentDetails.length) {
			dataStartPos = currentDetails.length	
		}

	}

}