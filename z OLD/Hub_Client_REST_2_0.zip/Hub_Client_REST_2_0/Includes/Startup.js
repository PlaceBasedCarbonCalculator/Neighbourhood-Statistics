// Variables from User screen
var svgMapDoc
var svgDataDoc
var svgThematicDoc
var svgChartDoc
var mapTitle

var mapColours =  new Array() //Blue,Green,Red,Grey,
mapColours[0] = new Array()
mapColours[1] = new Array("Blue","#BDCCEF|#4B73D3","#DEE5F7|#8DA7E3|#3F6AD1","#E6ECF9|#B9C9EE|#5A7FD7|#073EC3","#F3F6FC|#DAE2F6|#97AEE6|#3E69D0|#002BB8")
mapColours[2] = new Array("Green","#CDF5CD|#27D327","#E2F9E2|#7CE47C|#00CC00","#F2FCF2|#C0F2C0|#6FE26F|#01CC01","#FAFEFA|#BBF1BB|#7FE57F|#01CC01|#008400")
mapColours[3] = new Array("Red","#FFA199|#FF1E00","#F5CCCC|#FF7566|#FF1E00","#FFCCCC|#FFA199|#FF7566|#FF1E00","#FFCCCC|#FFA199|#FF7566|#FF1E00|#BF0000")
mapColours[4] = new Array("Grey","#666666|#DDDDDD","#555555|#999999|#DDDDDD","#444444|#888888|#BBBBBB|#EEEEEE","#444444|#666666|#999999|#BBBBBB|#EEEEEE")
	
//Variables for Thematic mapping options
var currentMapTopicPos = 0;
var currentMapTopicPage = 1;
var numTopicsPerPage = 15
var currentMapYearPos = 0;				// Year of current data if time series
var currentMapYearPage = 1;
var currentMapColour = 3;		
var numYearsPerPage = 15
var currentNumColours = 5				// Two, three, four, five
var currentClassification = 1  			// Equal Interval, Highlight extremes
var polygonColour = "#FFFFFF"			// Shade of polygon mouse is currently over
var highlightColour = "yellow"			// Shade of the highlighted area
var notAvailableColour = "white"		// Shade of the N/A area
var hasNotAvailable = false			// If there are any Not Applicable
var hasOrkShet	= false					// If Orkney/Shetland inset is visible

var tableColour = "#BDD0F2"				// Shade of data table the mouse is currently over
var timeSeries = false
var fullExtent =  new Array()			// Main map extent xMin yMin, width height
var mapXcoord = 0						// X-coord in map units of last click
var mapYcoord = 0						// Y-coord in map units of last click
var currentTool = ""					// Currently selected tool
var currentSelections = "" 				// List of selected areas (max 12)

var numDecimals = 0						// Number of decimals of current variable
var currentDetails =  new Array()		// Areas Details => name|value

var interBoundaries = false				// Boolean to show if intermeadite Boundaries are included
var showHighlight = true				// Boolean to show if hightlighting is to be shown

// Bar chart variables
var chartHeight = 85					// Height of the bar chart
var chartWidth = 230					// Width of the bar chart
var yOffset = 5							// 0ffset from base line

// TimeSeries variables
var timeSeriesHeight = 75				// Height of the time series 
var timeSeriesWidth = 100				// Width of the time series
var timeSeriesYoffset = 0				// Y-0ffset from base line
var timeSeriesMin = 0					// Min value of timeseries chart
var timeSeriesMax = 0					// Max value of timeseries chart

var thematicThesholds =  new Array()	// fillColour|minValue|maxValue
thematicThesholds[0] = new Array()		// RenderDetails => count|minValue|maxValue	
thematicThesholds[1] = new Array()		// fillColour|minValue|maxValue
thematicThesholds[2] = new Array()  	// fillColour|minValue|maxValue
thematicThesholds[3] = new Array()  	// fillColour|minValue|maxValue
thematicThesholds[4] = new Array()  	// fillColour|minValue|maxValue
thematicThesholds[5] = new Array()  	// fillColour|minValue|maxValue

// Variables for the Data Table
dataStartPos = 24						// The position of the first row in the array
dataRows = 24							// Max number of rows in data table
dataSliderMin = 15						// Minimum coords for slider box
dataSliderMax = 324						// Maximum coords for slider box
dataSliderSize = 30						// Number of coords moved each "click"
dataSliderPos = 0						// Current slider position
dataSliderActive = false				// Boolean to show status of slider
dataSortOrder = "onsSort"				// The type of sort applied to the data table
dataTableOffset = 0						// The position of data table in the SVG page


function initialise() {


	//The basic main SVG documents
	svgMapDoc=document.svgMap.getSVGDocument()
	svgDataDoc=document.svgData.getSVGDocument()
	svgThematicDoc=document.svgThematic.getSVGDocument()
	svgChartDoc=document.svgChart.getSVGDocument()

	// Get the original map extent
	var mapWin = svgMapDoc.getElementById('Map');
	fullExtent[0] = mapWin.getAttribute('viewBox').split(" ")[0]
	fullExtent[1] = mapWin.getAttribute('viewBox').split(" ")[1]
	fullExtent[2] = mapWin.getAttribute('viewBox').split(" ")[2]
	fullExtent[3] = mapWin.getAttribute('viewBox').split(" ")[3]
	


	// Set the current map topic to the first one in the list and populate 
	setCurrentMapTopic(0)
	setMapTopicRect()	
	
	
	var theValue = 'translate(165 13)';
	svgThematicDoc.getElementById('thematicDD1').setAttribute('transform', theValue);
	svgThematicDoc.getElementById('thematicDD1').setAttribute('display','inline')
	svgThematicDoc.getElementById('currentMapTopicRect').setAttribute('display','inline')

	// Get the number of time series intervals and populate 
	var theSeries = eval(TIMESERIES)

	if (theSeries.length > 1) {
		timeSeries = true
	   setCurrentYear(0)
	   setCurrentYearRect()	
	
	   var theValue = 'translate(35 13)';
	   svgThematicDoc.getElementById('thematicDD2').setAttribute('transform', theValue);
	   svgThematicDoc.getElementById('thematicDD2').setAttribute('display','inline') 
	   
	   svgThematicDoc.getElementById('currentYearRect').setAttribute('display','inline')
	   
	   svgThematicDoc.getElementById('yearDropDown').setAttribute('display','inline')
	   
	} else {
		
		//Move all the dropdown lists up
		svgThematicDoc.getElementById('yearDropDown').setAttribute('display','none')

		var theValue = 'translate(0 35)';
		svgThematicDoc.getElementById('numberDropDown').setAttribute('transform', theValue);

		var theValue = 'translate(0 70)';
		svgThematicDoc.getElementById('colourDropDown').setAttribute('transform', theValue);

		var theValue = 'translate(0 105)';
		svgThematicDoc.getElementById('classificationDropDown').setAttribute('transform', theValue);

		var theValue = 'translate(0 165)';
		svgThematicDoc.getElementById('showCity').setAttribute('transform', theValue);
		
		var theValue = 'translate(0 185)';
		svgThematicDoc.getElementById('showBoundary').setAttribute('transform', theValue);

		var theValue = 'translate(0 205)';
		svgThematicDoc.getElementById('showIntermeadiate').setAttribute('transform', theValue);

		var theValue = 'translate(0 225)';
		svgThematicDoc.getElementById('showIntermeadiate1').setAttribute('transform', theValue);

	}
	
	//Check if the intermediate boundaries are included
	if ((svgMapBoundary == "WARD") || (svgMapBoundary == "LSOA") || (svgMapBoundary == "MSOA") || (svgMapBoundary == "NUTS3"))	{
		svgThematicDoc.getElementById('showIntermeadiate').setAttribute('display','inline') 
		
		switch (parseInt(svgMapSize)) {
		
			case 1  :	svgThematicDoc.getElementById('showIntermeadiateText').getFirstChild().setData("NUTS2 boundaries :") 
						svgThematicDoc.getElementById('showIntermeadiateCross').setAttribute('display','none');			
						interBoundaries = true
						break;

			case 3  :	svgThematicDoc.getElementById('showIntermeadiateText').getFirstChild().setData("LA boundaries :") 
						interBoundaries = true
						break;
						
			case 4  :	if (svgMapBoundary == "MSOA") {
							svgThematicDoc.getElementById('showIntermeadiate').setAttribute('display','none') 
							svgThematicDoc.getElementById('showIntermeadiateCross').setAttribute('display','none');			
							svgMapDoc.getElementById(svgMapBoundary).setAttribute('class','bndLevel2')
							svgMapDoc.getElementById("WARD").getStyle().setProperty('class','bndOff')
							svgMapDoc.getElementById("LSOA").getStyle().setProperty('class','bndOff')
							interBoundaries = false
						}
						if (svgMapBoundary == "LSOA") {
							svgThematicDoc.getElementById('showIntermeadiateText').getFirstChild().setData("MSOA boundaries :") 
							svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().setData("WARD boundaries :") 
							
							svgThematicDoc.getElementById('showIntermeadiateCross').setAttribute('display','none');			
							svgThematicDoc.getElementById('showIntermeadiateCross1').setAttribute('display','none');			

							svgMapDoc.getElementById(svgMapBoundary).setAttribute('class','bndLevel2')
							svgMapDoc.getElementById("WARD").getStyle().setProperty('class','bndOff')
							svgMapDoc.getElementById("MSOA").getStyle().setProperty('class','bndOff')
							interBoundaries = true
						}
						if (svgMapBoundary == "WARD") {
							svgThematicDoc.getElementById('showIntermeadiate').setAttribute('display','none') 
							svgThematicDoc.getElementById('showIntermeadiateCross').setAttribute('display','none');			
			
							svgThematicDoc.getElementById('showIntermeadiate1').setAttribute('display','none');			

							svgMapDoc.getElementById(svgMapBoundary).setAttribute('class','bndLevel2')
							svgMapDoc.getElementById("MSOA").getStyle().setProperty('class','bndOff')
							svgMapDoc.getElementById("LSOA").getStyle().setProperty('class','bndOff')
							interBoundaries = false
						}
						break;
		}							
	}


	// Only display the selected "small-area" boundaries
	
	
	

	// Add the slider mouse-controls
	addEventListeners() 


	// Update the area boundary name
	svgThematicDoc.getElementById('showBoundaryText').getFirstChild().setData(svgMapBoundary + " boundaries :") 

	// Set the number of map colours and populate 
	setCurrentNumColours(currentNumColours)
	svgThematicDoc.getElementById('currentNumColoursRect').setAttribute('display','inline')

	var theValue = 'translate(35 13)';
	svgThematicDoc.getElementById('thematicDD3').setAttribute('transform', theValue);
	svgThematicDoc.getElementById('thematicDD3').setAttribute('display','inline')

	// Set the current map colours to the first one in the list and populate 
	var theColour = mapColours[currentMapColour][0]

	svgThematicDoc.getElementById('currentMapColoursText').getFirstChild().setData(theColour)
	svgThematicDoc.getElementById('currentMapColoursText').setAttribute('display','inline')
	svgThematicDoc.getElementById('currentMapColoursRect').setAttribute('display','inline')
	
	var theValue = 'translate(45 13)';
	svgThematicDoc.getElementById('thematicDD4').setAttribute('transform', theValue);
	svgThematicDoc.getElementById('thematicDD4').setAttribute('display','inline')


	// Set the type of classifiaction and populate 
	setCurrentClassification()

	var theValue = 'translate(95 13)';
	svgThematicDoc.getElementById('thematicDD5').setAttribute('transform', theValue);
	svgThematicDoc.getElementById('thematicDD5').setAttribute('display','inline')


	// Get the DataTable offset
	var theValue = 	svgDataDoc.getElementById('dataTable').getAttribute('transform');
	var startPos = theValue.indexOf(",")
	var endPos = theValue.indexOf(")")
	dataTableOffset = parseInt(theValue.substring(startPos+1,endPos))


	// Set the extent rectangle
	rectY = parseInt(fullExtent[1]) + parseInt(fullExtent[3])
	svgMapDoc.getElementById('currExtent').setAttribute('x',fullExtent[0])
	svgMapDoc.getElementById('currExtent').setAttribute('y',rectY*-1)
	svgMapDoc.getElementById('currExtent').setAttribute('width',fullExtent[2])
	svgMapDoc.getElementById('currExtent').setAttribute('height',fullExtent[3])
	svgMapDoc.getElementById('currExtent').setAttribute('display','inline')
		
	// Shade the map
	buildThresholds();
}


function addEventListeners() {

	// Add the event listeners for dataBox
	svgDataDoc.getElementById("sliderBox").addEventListener("mousedown",activateDataSlider,false)
	svgDataDoc.getElementById("sliderBox").addEventListener("mouseup",activateDataSlider,false)
	
	svgDataDoc.getElementById("sliderRect").addEventListener("mouseup",stopDataSlider,false)
	svgDataDoc.getElementById("sliderRect").addEventListener("mousemove",moveDataSlider,false)
	svgDataDoc.getElementById("sliderRect").addEventListener("click",clickDataSlider,false)
		
	svgDataDoc.getElementById("downArrow").addEventListener("click",dataDownArrow,false)
	svgDataDoc.getElementById("upArrow").addEventListener("click",dataUpArrow,false)

	svgMapDoc.getElementById("Map").addEventListener("click",getMapPos,false)
	svgMapDoc.getElementById("Map").addEventListener("mousemove",moveMap,false)
	svgMapDoc.getElementById("Map").addEventListener("mouseup",stopPan,false)
	svgMapDoc.getElementById("Map").addEventListener("mousedown",startPan,false)

	
	// Add the select event for the dataTable
	for (var i=1; i < 25; i++) {
		svgDataDoc.getElementById("rect"+i).addEventListener("mousedown",selectTable,false)
	}

	// Add the select event for the map areas
	svgMapDoc.getElementById(svgMapBoundary).addEventListener("mousedown",selectArea,false)


	// Add the event listners for MSOA and WARDS
	if (parseInt(svgMapSize) == 4) { 
		svgMapDoc.getElementById(svgMapBoundary).addEventListener("mouseover",queryArea,false)
		svgMapDoc.getElementById(svgMapBoundary).addEventListener("mouseout",queryArea,false)
	} 
}

