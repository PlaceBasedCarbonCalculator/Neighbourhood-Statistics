function setCurrentMapTopic(thePos) {
	var theVariables = eval("SHORTDESC")
	currentMapTopicPos = parseInt(thePos);
	
	var theValue = theVariables[currentMapTopicPos*currentMapTopicPage]
	
	if (theValue.length > 35) {
	  tmpName = theValue.substr(0,35) + "..."
	} else {
	  tmpName = theValue
	}	
		
	svgThematicDoc.getElementById('currentMapTopicText').getFirstChild().setData(tmpName)
	svgThematicDoc.getElementById('currentMapTopicText').setAttribute('display','inline')

	// Reset the map tools
	resetTools()
}

function setMapTopicRect() {
	var theVariables = eval("SHORTDESC")
	
	var numVars = theVariables.length
	if (numVars > numTopicsPerPage) {
		numVars = numTopicsPerPage
	}

	
	var startPos = currentMapTopicPage*numVars - numVars
	var theVar = 0
		
	for (i=startPos; i < (numVars*currentMapTopicPage); i++) {
		var theName = theVariables[i]
		if (theName.length > 32) {
		  tmpName = theName.substr(0,32) + "..."
		} else {
			tmpName = theName
		}
		svgThematicDoc.getElementById('mapTopic'+theVar).getFirstChild().setData(tmpName)//theVariables[i])
		theVar ++
	}
	
	var theSize = numTopicsPerPage*numVars + 5

	svgThematicDoc.getElementById('availMapTopicRect').setAttribute('height',theSize);
	
	
}


function toggleMapTopics(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('themVars').getAttribute('display')
	
	if (currStatus == "none") {	
		theDoc.getElementById('themVars').setAttribute('display','inline');
		if (timeSeries) {
			theDoc.getElementById('yearDropDown').setAttribute('display','none');
		}
		theDoc.getElementById('numberDropDown').setAttribute('display','none');
		theDoc.getElementById('colourDropDown').setAttribute('display','none');
		theDoc.getElementById('classificationDropDown').setAttribute('display','none');
		theDoc.getElementById('showBoundary').setAttribute('display','none');
		theDoc.getElementById('showCity').setAttribute('display','none')
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','none');	
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','none');
			}
		}
	
	} else {
		theDoc.getElementById('themVars').setAttribute('display','none');
		
		if (timeSeries) {
			theDoc.getElementById('yearDropDown').setAttribute('display','inline');
		}
		theDoc.getElementById('numberDropDown').setAttribute('display','inline');
		theDoc.getElementById('colourDropDown').setAttribute('display','inline');
		theDoc.getElementById('classificationDropDown').setAttribute('display','inline');	
		theDoc.getElementById('showBoundary').setAttribute('display','inline');
		theDoc.getElementById('showCity').setAttribute('display','inline')
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','inline');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','inline');
			}
		}


	}
	svgThematicDoc.getElementById('mapTopicPopup').setAttribute('display','none');
}

function hideMapTopicPopup(theTopic) {

	svgThematicDoc.getElementById('mapTopicPopup').setAttribute('display','none');
	
	//If necessary show the next dropdown
	var currStatus = svgThematicDoc.getElementById('themVars').getAttribute('display')
	var theSeries = eval(TIMESERIES)

	if (currStatus == 'none') {	
		if (theTopic == 99) {
				if (theSeries.length > 1) {
						svgThematicDoc.getElementById('yearDropDown').setAttribute('display','inline');
					} else {
						svgThematicDoc.getElementById('numberDropDown').setAttribute('display','inline');
		}
		}
	} 
}	

function showMapTopicPopup(theTopic, evt){	
	var theVariables = eval("LONGDESC")
	
	
	if (parseInt(theTopic) == 99) {
		theYpos = -4
		var shortName = svgThematicDoc.getElementById('currentMapTopicText').getFirstChild().getData()	
		var theDesc = theVariables[currentMapTopicPos*currentMapTopicPage]
		var descLength = theDesc.length
	} else {
		var theYpos = svgThematicDoc.getElementById('mapTopic'+theTopic).getAttribute('y')
		var shortName = svgThematicDoc.getElementById('mapTopic'+theTopic).getFirstChild().getData()
		var theDesc = theVariables[theTopic*currentMapTopicPage]
		var descLength = theDesc.length
	}	
	
	if (shortName == theDesc) {
		return
	}
	
	var tmpChar
	var startPos = 0
	var endPos = 45
	thePos = 0	
	
	for (x=1; x < 4; x++) {	
		if ((endPos > descLength) || (startPos >= descLength)){
			endPos = descLength
			theChar = " "
		} else {
			theChar = theDesc.substr(endPos,1)
		}
		var i = 0
		if (theChar != " ") {
			for (i=1; i < 45; i++) {
				tmpChar = theDesc.substr((endPos-i),1)
				if (tmpChar == " ") {
					thePos = i
					i = 46
				}
			}
			endPos = endPos - thePos
		}
		svgThematicDoc.getElementById('mapTopicPopupText'+x).getFirstChild().setData(theDesc.substring(startPos,endPos))
		startPos = endPos + 1
		endPos = startPos + 45
	}
	
	theValue = 'translate(-20 ' + (parseInt(theYpos)+30) + ')';
	svgThematicDoc.getElementById('mapTopicPopup').setAttribute('transform', theValue);
	
	if (svgThematicDoc.getElementById('mapTopicPopupText3').getFirstChild().getData.length == 0) {
		svgThematicDoc.getElementById('mapTopicPopupRect').setAttribute('height',27);
	} else {
		svgThematicDoc.getElementById('mapTopicPopupRect').setAttribute('height',35);
	}

	//If necessary hide the next dropdown
	var currStatus = svgThematicDoc.getElementById('themVars').getAttribute('display')
	var theSeries = eval(TIMESERIES)
	
	//If necessary show the next dropdown
	if (currStatus == 'inline')  {
		if (theSeries.length > 1) {
			svgThematicDoc.getElementById('yearDropDown').setAttribute('display','none');
		} else {
			svgThematicDoc.getElementById('numberDropDown').setAttribute('display','none');
		}
	} else {
		if (theTopic == 99) {
			if (theSeries.length > 1) {
				svgThematicDoc.getElementById('yearDropDown').setAttribute('display','none');
			} else {
				svgThematicDoc.getElementById('numberDropDown').setAttribute('display','none');
			}			
		}
	}
	svgThematicDoc.getElementById('mapTopicPopup').setAttribute('display','inline');
	
}	

function setCurrentYear() {
	var theVariables = eval("TIMESERIES")
	var theValue = theVariables[currentMapYearPos*currentMapYearPage]
	svgThematicDoc.getElementById('currentYearText').getFirstChild().setData(theValue)
	svgThematicDoc.getElementById('currentYearText').setAttribute('display','inline')

	// Reset the map tools
	resetTools()
}

function setCurrentYearRect() {
	var theVariables = eval("TIMESERIES")
	var numVars = theVariables.length
	
	var numVars = theVariables.length
	if (numVars > numYearsPerPage) {
		numVars = numYearsPerPage
	}
	var startPos = currentMapTopicPage*numVars - numVars
	var theVar = 0
		
	for (i=startPos; i < (numYearsPerPage*currentMapYearPage); i++) {
	   svgThematicDoc.getElementById('currentYear'+theVar).getFirstChild().setData(theVariables[i])
     	   theVar ++
	}

	var theSize = numVars*12 + 5
	//alert(theSize)
	svgThematicDoc.getElementById('availcurrentYearRect').setAttribute('height',theSize);

}

function toggleYearDetails(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('themCurrentYear').getAttribute('display')

	if (currStatus == "none") {	
		theDoc.getElementById('themCurrentYear').setAttribute('display','inline');
		theDoc.getElementById('numberDropDown').setAttribute('display','none');
		theDoc.getElementById('colourDropDown').setAttribute('display','none');
		theDoc.getElementById('classificationDropDown').setAttribute('display','none');
		theDoc.getElementById('showBoundary').setAttribute('display','none');
		theDoc.getElementById('showCity').setAttribute('display','none')	
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','none');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','none');
			}
		}
	} else {
		theDoc.getElementById('themCurrentYear').setAttribute('display','none');
		theDoc.getElementById('numberDropDown').setAttribute('display','inline');
		theDoc.getElementById('colourDropDown').setAttribute('display','inline');
		theDoc.getElementById('classificationDropDown').setAttribute('display','inline');
		theDoc.getElementById('showBoundary').setAttribute('display','inline');	
		theDoc.getElementById('showCity').setAttribute('display','inline')	
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','inline');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','inline');
			}
		}
	}
}


function setCurrentNumColours(thePos) {
	switch (currentNumColours) {
		case 2: var theDesc = "Two";break;
		case 3: var theDesc = "Three";break;
		case 4: var theDesc = "Four";break;
		case 5: var theDesc = "Five";break;
	}
	svgThematicDoc.getElementById('currentNumColoursText').getFirstChild().setData(theDesc)
	svgThematicDoc.getElementById('currentNumColoursText').setAttribute('display','inline')

	// Reset the map tools
	resetTools()
}

function toggleNumColours(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('themNumColours').getAttribute('display')

	if (currStatus == "none") {	
		theDoc.getElementById('themNumColours').setAttribute('display','inline');
		theDoc.getElementById('colourDropDown').setAttribute('display','none');
		theDoc.getElementById('classificationDropDown').setAttribute('display','none');
		theDoc.getElementById('showBoundary').setAttribute('display','none');
		theDoc.getElementById('showCity').setAttribute('display','none')	
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','none');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','none');
			}
		}
	} else {
		theDoc.getElementById('themNumColours').setAttribute('display','none');		
		theDoc.getElementById('colourDropDown').setAttribute('display','inline');
		theDoc.getElementById('classificationDropDown').setAttribute('display','inline');
		theDoc.getElementById('showBoundary').setAttribute('display','inline');	
		theDoc.getElementById('showCity').setAttribute('display','inline')	
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','inline');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','inline');
			}
		}
	}
}

function toggleNumberDetails(theStatus) {
	svgThematicDoc.getElementById('themNumColours').setAttribute('display','none');

	svgThematicDoc.getElementById('currentNumColoursRect').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('currentNumColoursText').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('numColoursHeading').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('thematicDD3').setAttribute('display',theStatus);
}

function setCurrentMapColour() {
	svgThematicDoc.getElementById('currentMapColoursText').getFirstChild().setData(mapColours[currentMapColour][0])
	svgThematicDoc.getElementById('currentMapColoursText').setAttribute('display','inline')

	// Reset the map tools
	resetTools()
}


function toggleMapColours(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('themColours').getAttribute('display')

	if (currStatus == "none") {	
		theDoc.getElementById('themColours').setAttribute('display','inline');
		theDoc.getElementById('classificationDropDown').setAttribute('display','none');
		theDoc.getElementById('showBoundary').setAttribute('display','none');
		theDoc.getElementById('showCity').setAttribute('display','none')	
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','none');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','none');
			}
		}
	} else {
		theDoc.getElementById('themColours').setAttribute('display','none');
		theDoc.getElementById('classificationDropDown').setAttribute('display','inline');
		theDoc.getElementById('showBoundary').setAttribute('display','inline');
		theDoc.getElementById('showCity').setAttribute('display','inline')	
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','inline');
		}
		if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
			theDoc.getElementById('showIntermeadiate1').setAttribute('display','inline');
		}
	}
}

function toggleColourDetails(theStatus) {

	svgThematicDoc.getElementById('themColours').setAttribute('display','none');
	
	svgThematicDoc.getElementById('currentMapColoursRect').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('currentMapColoursText').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('mapColoursHeading').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('thematicDD4').setAttribute('display',theStatus);
}




function setCurrentClassification() {
	var theDesc = svgThematicDoc.getElementById('mapClassification'+currentClassification).getFirstChild().getData()
	svgThematicDoc.getElementById('currentClassificationText').getFirstChild().setData(theDesc)
	svgThematicDoc.getElementById('currentClassificationText').setAttribute('display','inline')
	svgThematicDoc.getElementById('currentClassificationRect').setAttribute('display','inline')

	// Reset the map tools
	resetTools()
}


function toggleClassificationDetails(theStatus) {
	svgThematicDoc.getElementById('themClassification').setAttribute('display','none');
	
	svgThematicDoc.getElementById('currentClassificationRect').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('currentClassificationText').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('classificationHeading').setAttribute('display',theStatus);
	svgThematicDoc.getElementById('thematicDD5').setAttribute('display',theStatus);
	

}

function toggleClassification(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('themClassification').getAttribute('display')

	if (currStatus == "none") {	
		theDoc.getElementById('themClassification').setAttribute('display','inline');
		theDoc.getElementById('showBoundary').setAttribute('display','none');
		theDoc.getElementById('showCity').setAttribute('display','none')			
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','none');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','none');
			}
		}
	} else {
		theDoc.getElementById('themClassification').setAttribute('display','none');
		theDoc.getElementById('showBoundary').setAttribute('display','inline');
		theDoc.getElementById('showCity').setAttribute('display','inline')			
		if (interBoundaries) {
			theDoc.getElementById('showIntermeadiate').setAttribute('display','inline');
			if (svgThematicDoc.getElementById('showIntermeadiateText1').getFirstChild().getData.length > 1) {
				theDoc.getElementById('showIntermeadiate1').setAttribute('display','inline');
			}
		}
	}
}


function toggleBoundaries(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('showBoundaryCross').getAttribute('display')
	if (currStatus == "none") {	
		theDoc.getElementById('showBoundaryCross').setAttribute('display','inline');
		svgMapDoc.getElementById(svgMapBoundary).getStyle().setProperty('stroke','black')
	} else {
		theDoc.getElementById('showBoundaryCross').setAttribute('display','none');
		svgMapDoc.getElementById(svgMapBoundary).getStyle().setProperty('stroke','none')
	}
}

function toggleCityNames(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('showCityCross').getAttribute('display')
	if (currStatus == "none") {	
		theDoc.getElementById('showCityCross').setAttribute('display','inline');
		svgMapDoc.getElementById('cities').setAttribute('display','inline')
	} else {
		theDoc.getElementById('showCityCross').setAttribute('display','none');
		svgMapDoc.getElementById('cities').setAttribute('display','none')
	}
}


function toggleIntermeadiate(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	
	// Check if first or second intermediate boundary
	var theID = evt.target.getAttribute("id")
	
	if (theID.indexOf("1") < 0) {
		var currStatus = theDoc.getElementById('showIntermeadiateCross').getAttribute('display')

		if (currStatus == "none") {	
			theDoc.getElementById('showIntermeadiateCross').setAttribute('display','inline');
			switch (parseInt(svgMapSize)) {
		
				case 1  :	svgMapDoc.getElementById('NUTS2').setAttribute('class','bndLevel1');
							break;
						
				case 3  :	svgMapDoc.getElementById('LA').setAttribute('class','bndLevel1');
							break;
						
				case 4  :	if (theDoc.getElementById('showIntermeadiateCross1').getAttribute('display') == "none") {	
								svgMapDoc.getElementById('MSOA').setAttribute('class','bndLevel1');
							} else {
								svgMapDoc.getElementById('MSOA').setAttribute('class','bndLevel1a');
							}
							break;
			}							
		} else {
			theDoc.getElementById('showIntermeadiateCross').setAttribute('display','none');
			switch (parseInt(svgMapSize)) {
			
				case 1  :	svgMapDoc.getElementById('NUTS2').setAttribute('class','bndOff');
							break;
						
				case 3  :	svgMapDoc.getElementById('LA').setAttribute('class','bndOff');
							break;
							
				case 4  :	svgMapDoc.getElementById('MSOA').setAttribute('class','bndOff');
							break;
			}
		}
	} else {
		var currStatus = theDoc.getElementById('showIntermeadiateCross1').getAttribute('display')
		
		if (currStatus == "none") {	
			theDoc.getElementById('showIntermeadiateCross1').setAttribute('display','inline');
			if (theDoc.getElementById('showIntermeadiateCross').getAttribute('display') == "none") {
				svgMapDoc.getElementById('WARD').setAttribute('class','bndLevel1');						
			} else {
				svgMapDoc.getElementById('WARD').setAttribute('class','bndLevel1a');								
			}
		} else {
			theDoc.getElementById('showIntermeadiateCross1').setAttribute('display','none');
			svgMapDoc.getElementById('WARD').setAttribute('class','bndOff');
		}	
	}
}

function toggleBarChart(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('showBarChartCross').getAttribute('display')
	if (currStatus == "none") {	
		theDoc.getElementById('showBarChartCross').setAttribute('display','inline');
		buildBarChart()
	} else {
		theDoc.getElementById('showBarChartCross').setAttribute('display','none');
		clearBarChart()
	}
}

function buildThresholds() {
	
	var addArea = true
	
	// Determine which variable is currently selected
	currentDetails = new Array()
	var theVars = eval(SHORTDESC)
	var numVars = theVars.length
	thePos = getCurrentVariable()

	// Process the selected variables and get the max/min values together with the total number
	var theValues = new Array()
	currentDetails = new Array()
	hasNotAvailable = false

	switch (svgMapBoundary) {
	
		case "WARD" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)
						break;
		case "MSOA" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)	
						break;
		case "LSOA" :	var theList = svgMapBoundary+'List_' + 	svgMapArea
						break;
		default : 		var theList = svgMapBoundary+'List'
	}

	for (i=0; i < eval(theList).length;i++) {
		
		var onsSort = eval(theList)[i].split("|")[0]
		var areaCode = eval(theList)[i].split("|")[1]
		var areaName = eval(theList)[i].split("|")[2]
		addArea = true

				
		if ((svgMapBoundary == "LA") || (svgMapBoundary == "PCO") || (svgMapBoundary == "EA")){
			var gorCode = eval(theList)[i].split("|")[3]
					
			if (parseInt(svgMapSize) == 2) {
				if ((gorCode != "152") && (gorCode != "220") && (gorCode != "179")) {
					gorCode = "064"
				}
			}
			
			// Check for national/regional extent
			if (svgMapArea.length > 0) {
				if (gorCode != svgMapArea) {
						addArea = false
				}
			}	
		} 
		
		if ((svgMapBoundary == "WARD") || (svgMapBoundary == "MSOA") || (svgMapBoundary == "LSOA")){
			var laCode = eval(theList)[i].split("|")[3]
							
			if (laCode != svgMapArea) {
				addArea = false
			}	
		} 
		
		if (addArea) {
			var theDetails = eval (svgMapBoundary + "_" + areaCode)
			if (theDetails.length == 0) {
				continue
			}
			var fieldValue = theDetails[thePos]
							
			if (fieldValue == "..") {
				hasNotAvailable = true
				continue
			}
		
			setDecimals(fieldValue.toString())
			theValues[theValues.length] = parseFloat(fieldValue) 
			currentDetails[currentDetails.length] = areaName + "|" + parseFloat(fieldValue) + "|" + onsSort 
		}
	}
	theValues.sort(numberOrder);

	renderMin = parseFloat(theValues[0]);
	renderMax = parseFloat(theValues[theValues.length-1]);
	renderCount = theValues.length
		
	renderRange = renderMax - renderMin;
	
	renderBreakIncrement = renderRange / currentNumColours;
	renderRecordIncrement = Math.round(renderCount / currentNumColours);

	//alert("Render Count : " + renderCount + "\n" + "Render Min : " + renderMin + "\n" + "Render Max : " + renderMax + "\n" + "Render Range : " + renderRange + "\n" + "Render Break Increment : " + renderBreakIncrement + "\n" + "Render Record Increment : " + renderRecordIncrement)

	var u = Math.pow(10,numDecimals);
	var theIncre = renderMin;
	var theIncre2 = theIncre;
	var	theShades = mapColours[currentMapColour][currentNumColours-1]

	thematicThesholds[0][0] = renderCount
	thematicThesholds[0][1] = renderMin
	thematicThesholds[0][2] = renderMax
	
	if (theIncre!=0) {
		theIncre2 = parseInt(theIncre * u + (5/10)) / u;
	}
	
	for (var i=1; i<=currentNumColours;i++) {
		thematicThesholds[i][0] = theShades.split("|")[i-1]	//colour
		thematicThesholds[i][1] = theIncre2;	//min value
	
		theIncre = theIncre + renderBreakIncrement;
	
		if (theIncre!=0) {
			theIncre2 = parseInt(theIncre * u + (5/10)) / u;
		} else {
			theIncre2 = theIncre;
		}
		thematicThesholds[i][2] = theIncre2;
	}

	// Initialise the datatable 
	var numVars = thematicThesholds[0][0]
	
	if (numVars < dataRows) {
		dataStartPos = numVars
	}



	// Thematically shade the map using the current variable
	colourMap()
		
		
	// Build the legend
	buildLegend()
	
	// Update the table
	if (thematicThesholds[0][0] < 500) {

		//Build the dataTable
		initDataTable()
		buildDataTable()
		
		
		//Build the bar chart (either "normal" or "index" bar chart
		var theTypes = eval(TYPEDESC)
		var typeDetails = theTypes[currentMapTopicPos*currentMapTopicPage]
		var varUnits = typeDetails.split("|")[1]

		if (varUnits.indexOf("Extra-Regio=100") == -1) {
			buildBarChart()
		} else {
			buildIndexBarChart()
		}
		
		//Initialise the TimeSeries 
		if (timeSeries) {
			clearTimeSeries()
			buildTimeSeriesAxes()
		}	
	}
		
	//Add the city names (but turn them off for National level maps
	//svgMapDoc.getElementById('cities').setAttribute('display','none')
	//addCities();
	
	//if (svgMapSize == 3) {
	//	svgMapDoc.getElementById('cities').setAttribute('display','inline')
	//	svgThematicDoc.getElementById('showCityCross').setAttribute('display','inline');
	//} else {
		svgMapDoc.getElementById('cities').setAttribute('display','none')
		svgThematicDoc.getElementById('showCityCross').setAttribute('display','none');
	//}
}

function colourMap()  {

	var addArea = true

	// Process the selected variables and get the max/min values together with the total number
	var svgMapDoc=document.svgMap.getSVGDocument().rootElement

	// Determine which variable is currently selected
	var theDetails = eval(SHORTDESC)
	var numVars = theDetails.length
	
	thePos = getCurrentVariable()

	switch (svgMapBoundary) {
	
		case "WARD" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)
						break;
		case "MSOA" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)	
						break;
		case "LSOA" :	var theList = svgMapBoundary+'List_' + 	svgMapArea
						break;
		default : 		var theList = svgMapBoundary+'List'
	}

	for (i=0; i < eval(theList).length;i++) {
	
		var areaCode = eval(theList)[i].split("|")[1]
				
		if ((svgMapBoundary == "LA") || (svgMapBoundary == "PCO") || (svgMapBoundary == "EA")){
			var gorCode = eval(theList)[i].split("|")[3]
					
			if (parseInt(svgMapSize) == 2) {
				if ((gorCode != "152") && (gorCode != "220") && (gorCode != "179")) {
					gorCode = "064"
				}
			}
			
			// Check for national/regional extent
			if (svgMapArea.length > 0) {
				if (gorCode != svgMapArea) {
						addArea = false
				}
			}	
		} 
		
		if ((svgMapBoundary == "WARD") || (svgMapBoundary == "MSOA") || (svgMapBoundary == "LSOA")){
			var laCode = eval(theList)[i].split("|")[3]
							
			if (laCode != svgMapArea) {
				addArea = false
			}	
		} 
		
		if (addArea) {
			var theDetails = eval (svgMapBoundary + "_" + areaCode)
			if (theDetails.length == 0) {
				continue
			}
			var fieldValue = theDetails[thePos]
		
			if (fieldValue == "..") {
				//continue
			} else {		
				setDecimals(fieldValue.toString())

				// Determine which category the values falls into
				for (x=1; x <= currentNumColours; x++) {
					theShade = thematicThesholds[x][0]
					minValue = thematicThesholds[x][1]
					maxValue = thematicThesholds[x][2]
		
					if (parseFloat(fieldValue) > (minValue-Math.pow(10,numDecimals)) && parseFloat(fieldValue) <= maxValue) {
						fillShade = theShade
						x = 99
					}
				}	
			
				if (svgMapDoc.getElementById(areaCode) != null) {
					svgMapDoc.getElementById(areaCode).getStyle().setProperty('fill',fillShade)
				
					if (svgMapSize == 1) {

					//if ((svgMapBoundary == "CTRY") || (svgMapBoundary == "LA") || (svgMapBoundary.indexOf("NUTS") > -1)) {
						var areaList = svgMapDoc.getElementById("Ork_Shet").getChildNodes()
						if (areaList.item(3).getAttribute("id") == areaCode) {
							areaList.item(3).getStyle().setProperty('fill',fillShade)
						}
						if (areaList.item(7).getAttribute("id") == areaCode) {							
							areaList.item(7).getStyle().setProperty('fill',fillShade)
						}
					}	
				}	
			}
		}
		addArea = true
	}
}

function highlightMap(areaName) {
	var areaCode = getAreaCode(areaName)
	
	polygonColour = svgMapDoc.getElementById(areaCode).getStyle().getPropertyValue("fill");
	svgMapDoc.getElementById(areaCode).getStyle().setProperty("fill",highlightColour);

	
	if (svgMapSize == 1) {
	//if ((svgMapBoundary == "CTRY") || (svgMapBoundary == "LA") || (svgMapBoundary.indexOf("NUTS") > -1)) {
		var areaList = svgMapDoc.getElementById("Ork_Shet").getChildNodes()
		if (areaList.item(3).getAttribute("id") == areaCode) {
			areaList.item(3).getStyle().setProperty('fill',highlightColour)
		}
		if (areaList.item(7).getAttribute("id") == areaCode) {	
			areaList.item(7).getStyle().setProperty('fill',highlightColour)
		}
	}
}

function lowlightMap(areaName) {

	var areaCode = getAreaCode(areaName)
	svgMapDoc.getElementById(areaCode).getStyle().setProperty('fill',polygonColour)


	if (svgMapSize == 1) {
		var areaList = svgMapDoc.getElementById("Ork_Shet").getChildNodes()
		if (areaList.item(3).getAttribute("id") == areaCode) {
			areaList.item(3).getStyle().setProperty('fill',polygonColour)
		}
		
		if (areaList.item(7).getAttribute("id") == areaCode) {
			areaList.item(7).getStyle().setProperty('fill',polygonColour)
		}
	}


}