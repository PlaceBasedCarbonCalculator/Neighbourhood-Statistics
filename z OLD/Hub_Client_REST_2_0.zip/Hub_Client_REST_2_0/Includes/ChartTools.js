function buildBarChart()  {

	clearBarChart()

	var targetLayer = svgChartDoc.getElementById("barChart");
	
	var numBars = thematicThesholds[0][0]
	var barMin = thematicThesholds[0][1] - (thematicThesholds[0][1]*0.1)
	var barMax = thematicThesholds[0][2] + (thematicThesholds[0][2]*0.1)
	var barDiff = barMax - barMin

	var barFactor = barDiff /chartHeight
	var barWidth  = chartWidth / numBars
	var barUnits =  barDiff/(chartHeight-5)

	var overEvent = "highlightBarChart(evt)"
	var outEvent = "lowlightBarChart(evt)"

	currentDetails.sort(numberDescending)

	for (i=0; i < currentDetails.length; i++) {

		var theName = currentDetails[i].split("|")[0]
		var theValue = currentDetails[i].split("|")[1]
		var theCode = currentDetails[i].split("|")[2] 
	
		// Determine which category the values falls into
		for (x=1; x <= currentNumColours; x++) {
			theShade = thematicThesholds[x][0]
			minValue = thematicThesholds[x][1]
			maxValue = thematicThesholds[x][2]
		
			if (theValue > (minValue-Math.pow(10,numDecimals)) && theValue <= maxValue) {
				fillShade = theShade
				break
			}
		}

		barValue = yOffset+(theValue - barMin)/barUnits
		var theID = theCode+"B"+fillShade	
		var overEvent = "mouseOverChart(\"" + theID+ "\")"
		var outEvent = "mouseOutChart(\"" + theID + "\")"
		var downEvent = "selectBarChart(evt)"
	
		var newRect = svgChartDoc.createElement("rect");
		newRect.setAttribute("x",(i*barWidth)-8);
		newRect.setAttribute("y","-85");
		newRect.setAttribute("width",barWidth);
		newRect.setAttribute("height",barValue);
		newRect.setAttribute("id",theID);
		newRect.setAttribute("fill",fillShade);
		newRect.setAttribute("stroke",fillShade);
		newRect.setAttribute("onmouseover",overEvent);
		newRect.setAttribute("onmouseout",outEvent);
		newRect.setAttribute("onmousedown",downEvent);
		
			
		targetLayer.appendChild(newRect);
	}
	
	// Set the max and min values
	var theText = formatValues(parseInt(barMax).toString())
	svgChartDoc.getElementById('yMaxValue').getFirstChild().setData(theText)
	
	var theText = formatValues(parseInt(barMin).toString())
	svgChartDoc.getElementById('yMinValue').getFirstChild().setData(theText)
	
	// Reset the x-axis
	svgChartDoc.getElementById('yMidValue').getFirstChild().setData(" ")
	svgChartDoc.getElementById('xAxis').setAttribute("y1","-85")
	svgChartDoc.getElementById('xAxis').setAttribute("y2","-85")
	
	
}

function mouseOverChart(theID) {

	if (currentTool == "select") {
		return
	}

	thePos = theID.indexOf("B")
	svgChartDoc.getElementById(theID).getStyle().setProperty("fill",highlightColour);
	svgChartDoc.getElementById(theID).getStyle().setProperty("stroke",highlightColour);

	currentBar = theID.substr(0,thePos)
	
	// Highlight the table and map
	for (i=0; i < currentDetails.length; i++) {
		var areaName = currentDetails[i].split("|")[0]
		var theValue = currentDetails[i].split("|")[1]
		var theCode = currentDetails[i].split("|")[2] 
	
		if (theCode == parseInt(currentBar)) {
			break
		}
	}
	if (thematicThesholds[0][0] < 500) {
		hightlightTable(areaName)
	}
	areaName = areaName.replace(",","")
	highlightMap(areaName)
		
	// Build the timeSeries chart if required
	if (timeSeries) {
		areaCode = getAreaCode(areaName)
		clearTimeSeries()
		buildTimeSeries(areaCode)
	}
	
	svgChartDoc.getElementById("barchartPopupText1").getFirstChild().setData(areaName + " : " + formatValues(theValue))

}

function mouseOutChart(theID) {

	if (currentTool == "select") {
		return
	}
	
	thePos = theID.indexOf("B")
	theColour = theID.substr(thePos+1,theID.length)
	
	svgChartDoc.getElementById(theID).getStyle().setProperty("fill",theColour);
	svgChartDoc.getElementById(theID).getStyle().setProperty("stroke",theColour);

	// Lowlight the table and map
	for (i=0; i < currentDetails.length; i++) {
		var areaName = currentDetails[i].split("|")[0]
		var theCode = currentDetails[i].split("|")[2] 
	
		if (theCode == parseInt(currentBar)) {
			break
		}
	}
	
	
	// Lowlight the table
	if (thematicThesholds[0][0] < 500) {
		lowlightTable(areaName)
	}
	areaName = areaName.replace(",","")
	
	// Lowlight the map
	lowlightMap(areaName)
	
	// Clear the timeseries
	if (timeSeries) {
		clearTimeSeries()
	}
	
	svgChartDoc.getElementById("barchartPopupText1").getFirstChild().setData("")
}


function highlightChart(areaName) {

	var MyObjs = new Array;
	var theChart = svgChartDoc.getElementById("barChart");
	var barsInChart = theChart.getChildNodes();
	var numBars = barsInChart.length;
	var foundOne = false

	if (areaName.indexOf("..") > -1) {
		var isShortened = true
		areaName = areaName.replace("..","")
	} else {
		var isShortened = false	
	}

	// Get the code from currentDetails
	for (i=0; i < currentDetails.length; i++) {
		var theName = currentDetails[i].split("|")[0]
		var theCode = currentDetails[i].split("|")[2] 
		
		//Remove any commas
		theName = theName.replace(",","")

		// Check if the name has been shortened
		if (isShortened) {
			if (theName.indexOf(areaName) > -1) {
				break
			}
		} else {
			if (theName == areaName) {
				break
			}
		}
	}	

	for (i=0; i < numBars; i++) {
		var theType = barsInChart.item(i).nodeType;
		
		if (theType==1)	{
			var theID = barsInChart.item(i).getAttribute('id');
			var tmpCode = theID.substr(0,theID.indexOf("B"))

			if (tmpCode == theCode) {
				foundOne = true
				break;	
			}
		}
	}

	if (foundOne) {
		svgChartDoc.getElementById(theID).getStyle().setProperty("fill",highlightColour);
		svgChartDoc.getElementById(theID).getStyle().setProperty("stroke",highlightColour);
	}
}

function lowlightChart(areaName) {
	var theChart = svgChartDoc.getElementById("barChart");
	var barsInChart = theChart.getChildNodes();
	var numBars = barsInChart.length;
	var foundOne = false

	if (areaName.indexOf("..") > -1) {
		var isShortened = true
		areaName = areaName.replace("..","")
	} else {
		var isShortened = false	
	}


	// Get the code from currentDetails
	for (i=0; i < currentDetails.length; i++) {
		var theName = currentDetails[i].split("|")[0]
		var theCode = currentDetails[i].split("|")[2] 
		
		//Remove any commas
		theName = theName.replace(",","")

		// Check if the name has been shortened
		if (isShortened) {
			if (theName.indexOf(areaName) > -1) {
				break
			}
		} else {
			if (theName == areaName) {
				break
			}
		}
	}	


	for (i=0; i < numBars; i++) {
		var theType = barsInChart.item(i).nodeType;
		
		if (theType==1)	{
			var theID = barsInChart.item(i).getAttribute('id');
			var tmpCode = theID.substr(0,theID.indexOf("B"))

			if (tmpCode == theCode) {
				theColour = theID.substr(theID.indexOf("B")+1,theID.length)
				foundOne = true	
				break;	
			}
		}
	}

	if (foundOne) {
		svgChartDoc.getElementById(theID).getStyle().setProperty("fill",theColour);
		svgChartDoc.getElementById(theID).getStyle().setProperty("stroke",theColour);
	}
}

function clearBarChart() {
	var numBars = svgChartDoc.getElementById("barChart").getChildNodes().length;

	if (numBars > 1) {
		for (i=0; i < numBars - 1; i++) {
			var mylayer = svgChartDoc.getElementById('barChart');
			var oldcontent = svgChartDoc.getElementById('barChart').getFirstChild().getNextSibling();
			mylayer.removeChild(oldcontent);
		}
	}	
}

function buildIndexBarChart()  {

	clearBarChart()


	var targetLayer = svgChartDoc.getElementById("barChart");
	
	var numBars = thematicThesholds[0][0]
	var barMin = (parseInt((thematicThesholds[0][1] - 10)/10)*10)
	var barMax = (parseInt((thematicThesholds[0][2] + 10)/10)*10)
	var barDiff = barMax - barMin




	var barFactor = barDiff /chartHeight
	var barWidth  = chartWidth / numBars
	var barUnits =  barDiff/(chartHeight-yOffset)
	var overEvent = "highlightBarChart(evt)"
	var outEvent = "lowlightBarChart(evt)"
	var downEvent = "selectBarChart(evt)"
	var axisPos = 85-(yOffset+ (100 - barMin)/barUnits)

	// Set the max and min values and move the graph
	var theText = formatValues(barMax.toString())
	svgChartDoc.getElementById('yMaxValue').getFirstChild().setData(theText)
	var theText = formatValues(barMin.toString())
	svgChartDoc.getElementById('yMinValue').getFirstChild().setData(theText)
	svgChartDoc.getElementById('yMidValue').getFirstChild().setData("100")
	svgChartDoc.getElementById('yMidValue').setAttribute("y",(axisPos)+2)
	svgChartDoc.getElementById('xAxis').setAttribute("width",barUnits)
	svgChartDoc.getElementById('xAxis').setAttribute("y1",axisPos*-1)
	svgChartDoc.getElementById('xAxis').setAttribute("y2",axisPos*-1)
	svgChartDoc.getElementById('yMidMarker').setAttribute("y1",axisPos*-1)
	svgChartDoc.getElementById('yMidMarker').setAttribute("y2",axisPos*-1)


	
	currentDetails.sort(numberDescending)


	for (i=0; i < currentDetails.length; i++) {

		var theName = currentDetails[i].split("|")[0]
		var theValue = currentDetails[i].split("|")[1]
		var theCode = currentDetails[i].split("|")[2] 
	
		// Determine which category the values falls into
		for (x=1; x <= currentNumColours; x++) {
			theShade = thematicThesholds[x][0]
			minValue = thematicThesholds[x][1]
			maxValue = thematicThesholds[x][2]
		
			if (theValue > (minValue-Math.pow(10,numDecimals)) && theValue <= maxValue) {
				fillShade = theShade
				break
			}
		}

		barValue = yOffset+(theValue/barUnits)
		baseLine = yOffset+(100/barUnits)
		barValue = barValue-baseLine
			
		var theID = theCode+"B"+fillShade	 
		var overEvent = "mouseOverChart(\"" + theID+ "\")"
		var outEvent = "mouseOutChart(\"" + theID + "\")"
		
		var newRect = svgChartDoc.createElement("rect");
		newRect.setAttribute("x",(i*barWidth)-8);
		newRect.setAttribute("width",barWidth);
		
		
		
		if (barValue <= 0) {
			newRect.setAttribute("y",(axisPos*-1)+barValue);
			newRect.setAttribute("height",barValue*-1);
		} else {
			newRect.setAttribute("y",axisPos*-1);
			newRect.setAttribute("height",barValue);
		}
		
		if (barValue == 0) {
			newRect.setAttribute("y",(axisPos*-1)-barUnits*0.5);
			newRect.setAttribute("height",barUnits);
		}		
		newRect.setAttribute("id",theID);
		newRect.setAttribute("fill",fillShade);
		newRect.setAttribute("stroke","none");
		newRect.setAttribute("onmouseover",overEvent);
		newRect.setAttribute("onmouseout",outEvent);
		newRect.setAttribute("onmousedown",downEvent);
		

			
		targetLayer.appendChild(newRect);
	}
}


function selectBarChart(evt) {

	if (currentTool != "select") {
		return
	}	
	
	// Get the selected area
	var theDoc = evt.getTarget().getOwnerDocument()
	var theID = evt.target.getAttribute("id");
	var thePos = theID.indexOf("B")	
	theID = theID.substr(0,thePos)
	
	// Get the area code 
	for (var i=0; i < currentDetails.length; i++) {
		if (parseInt(currentDetails[i].split("|")[2]) == parseInt(theID)) {
			var theName = currentDetails[i].split("|")[0]
		}		
	}	
	theName = theName.replace(",","")
	var areaCode = getAreaCode(theName)	
		
	updateSelections (areaCode)
}


function buildTimeSeriesAxes(){

	var areaList = svgMapDoc.getElementById(svgMapBoundary).getChildNodes()
	var numYears = eval("TIMESERIES").length
	var thePos = getCurrentVariable() - currentMapYearPos

	timeSeriesMin = 0
	timeSeriesMax = 0

	for (i=0; i < areaList.length - 1; i++) {
		
		if (areaList.item(i).getNodeType() == 1) {
			
			theArea = areaList.item(i).getAttribute("id")
			
			// Loop through all the areas to get the max/min of all the timeseries
			var theList = eval(svgMapBoundary+'_' + theArea)
			
			if ((timeSeriesMin == 0) && (timeSeriesMax == 0)){
				timeSeriesMin = parseInt(theList[thePos])
				timeSeriesMax = parseInt(theList[thePos])
			}
			
			for (j=thePos; j < (thePos+numYears);j++) {
							
				if (parseInt(theList[j]) < timeSeriesMin) {
					timeSeriesMin = parseInt(theList[j])
				}	
				if (parseInt(theList[j]) > timeSeriesMax) {
					timeSeriesMax = parseInt(theList[j])
				}			
			}
		}	
	}	



	timeSeriesMin = parseInt(timeSeriesMin - Math.abs(timeSeriesMin*0.15))
	if (timeSeriesMax < 20) {
		timeSeriesMax = parseInt(timeSeriesMax + (timeSeriesMax*0.5))
	} else {
		timeSeriesMax = parseInt(timeSeriesMax + (timeSeriesMax*0.05))	
	}
	timeSeriesMin = getAxisValue(timeSeriesMin)
	timeSeriesMax = getAxisValue(timeSeriesMax)
	var seriesDiff = timeSeriesMax - timeSeriesMin

	// Add the connecting line
	var targetLayer = svgChartDoc.getElementById("timeSeriesAxes");
	var seriesWidth  = timeSeriesWidth / numYears
	var theTransform = "scale(1, -1)"

	for (i=0; i < numYears; i++){
		theYear = eval("TIMESERIES")[i].toString()
		theYear = "'"+theYear.substr(2,2)

		var newLine = svgChartDoc.createElement("line");
		newLine.setAttribute("x1",(i*seriesWidth)+7);
		newLine.setAttribute("y1",timeSeriesHeight*-1);
		newLine.setAttribute("x2",(i*seriesWidth)+7);
		newLine.setAttribute("y2",(timeSeriesHeight+5)*-1);
		newLine.setAttribute("id","L" + i);
		newLine.setAttribute("fill","none");
		newLine.setAttribute("stroke","black");
		newLine.setAttribute("stroke-width","0.5")
		targetLayer.appendChild(newLine);		

		if  (i%2 == 0) { 	
    		var textNode = svgChartDoc.createTextNode(theYear);
    		newText = svgChartDoc.createElement("text");
    		newText.setAttribute('transform', theTransform)
	   		newText.setAttribute("fill", "black");
    		newText.setAttribute("font-size", "6");
    		newText.setAttribute("text-anchor","middle");
	   		newText.setAttribute("x", (i*seriesWidth)+7);
    		newText.setAttribute("y", (timeSeriesHeight+10));
	    	newText.appendChild(textNode);
    		targetLayer.appendChild(newText); 
		}
	}		

	// Set the y axis values
	var theText = formatValues(timeSeriesMin.toString())
	svgChartDoc.getElementById('y0Value').getFirstChild().setData(theText)

	var theValue = parseInt(timeSeriesMin + (seriesDiff*0.25))
	var theText = formatValues(theValue.toString())
	svgChartDoc.getElementById('y25Value').getFirstChild().setData(theText)
	
	var theValue = parseInt(timeSeriesMin + (seriesDiff*0.5))
	var theText = formatValues(theValue.toString())
	svgChartDoc.getElementById('y50Value').getFirstChild().setData(theText)

	var theValue = parseInt(timeSeriesMin + (seriesDiff*0.75))
	var theText = formatValues(theValue.toString())
	svgChartDoc.getElementById('y75Value').getFirstChild().setData(theText)
		
	var theText = formatValues(timeSeriesMax.toString())
	svgChartDoc.getElementById('y100Value').getFirstChild().setData(theText)


	svgChartDoc.getElementById("timeSeriesAxes").setAttribute("display","inline")
}


function buildTimeSeries(areaCode)  {

	var targetLayer = svgChartDoc.getElementById("timeSeries");
	var numYears = eval("TIMESERIES").length
	var theValues = new Array()

	// Get the position of the current variable
	var thePos = getCurrentVariable() - currentMapYearPos
	var theDetails = eval (svgMapBoundary + "_" + areaCode)
	
	// Extract the timeSeries data
	for (i=0; i < numYears; i++) {
		var theYear = eval("TIMESERIES")[i]
		var theValue = theDetails[thePos]
		
		theValues[theValues.length] = eval("TIMESERIES")[i] + "|" + theDetails[thePos]
		thePos++
	}

	var seriesDiff = timeSeriesMax - timeSeriesMin
	var seriesFactor = seriesDiff / timeSeriesHeight
	var seriesWidth  = timeSeriesWidth / numYears
	var seriesUnits =  seriesDiff/(timeSeriesHeight-timeSeriesYoffset)

	//var overEvent = "highlightTimeSeries(evt)"
	//var outEvent = "lowlightTimeSeries(evt)"
	var thePath = "M "

	// Build the connecting line
	for (i=0; i < theValues.length; i++) {
		var theValue = theValues[i].split("|")[1]
		var seriesValue = timeSeriesYoffset+(theValue - timeSeriesMin)/seriesUnits
		var xCoord = parseInt((i*seriesWidth))
		var yCoord = parseInt((timeSeriesHeight - seriesValue))

		// Add the connecting line
		if (i > 0) {
			var newLine = svgChartDoc.createElement("line");
			newLine.setAttribute("x1",prevX);
			newLine.setAttribute("y1",prevY);
			newLine.setAttribute("x2",(i*seriesWidth));
			newLine.setAttribute("y2",timeSeriesHeight - seriesValue);
			newLine.setAttribute("id","L" + i);
			newLine.setAttribute("fill","none");
			newLine.setAttribute("stroke","blue");
			newLine.setAttribute("stroke-width","0.5")
			targetLayer.appendChild(newLine);		
		}	
		prevX = (i*seriesWidth)
		prevY = timeSeriesHeight - seriesValue
	}	
	
	var prevX = 0
	var prevY = 0

	var newPath = svgChartDoc.createElement("path");
	newPath.setAttribute("d",thePath);
	newPath.setAttribute("id","thePath");
	newPath.setAttribute("fill","none");
	newPath.setAttribute("stroke","blue");
	newPath.setAttribute("stroke-width","0.5")
	targetLayer.appendChild(newLine);

	for (i=0; i < theValues.length; i++) {
		var theYear = theValues[i].split("|")[0]
		var theValue = theValues[i].split("|")[1]
	
		var seriesValue = timeSeriesYoffset+(theValue - timeSeriesMin)/seriesUnits
		var theID = areaCode+"T"+theYear
		
		//var overEvent = "mouseOverSeries(\"" + theID+ "\")"
		//var outEvent = "mouseOutSeries(\"" + theID + "\")"
		
		var newCircle = svgChartDoc.createElement("circle");
		newCircle.setAttribute("cx",(i*seriesWidth));
		newCircle.setAttribute("cy",timeSeriesHeight - seriesValue);
		newCircle.setAttribute("r","2");
		newCircle.setAttribute("id",theID);
		
		if (theYear == parseInt(svgThematicDoc.getElementById('currentYearText').getFirstChild().getData())) {
			newCircle.setAttribute("r","3");
			newCircle.setAttribute("fill",highlightColour);
			newCircle.setAttribute("stroke","black");
			newCircle.setAttribute("stroke-width","0.5");
		} else {
			newCircle.setAttribute("fill","blue");
			newCircle.setAttribute("stroke","blue");		
		}
		//newCircle.setAttribute("onmouseover",overEvent);
		//newCircle.setAttribute("onmouseout",outEvent);
		targetLayer.appendChild(newCircle);
		thePos++
	}
	
}

function clearTimeSeries() {
	var numYears = svgChartDoc.getElementById("timeSeries").getChildNodes().length;

	if (numYears > 1) {
		for (i=0; i < numYears - 1; i++) {
			var theSeries = svgChartDoc.getElementById('timeSeries');
			var oldData = svgChartDoc.getElementById('timeSeries').getFirstChild().getNextSibling();
			theSeries.removeChild(oldData);
		}
	}
}


function buildMultiTimeSeries(areaCode, seriesNum)  {

	seriesNum = seriesNum/2

	var targetLayer = svgChartDoc.getElementById("timeSeries");
	var numYears = eval("TIMESERIES").length
	var theValues = new Array()
	//var theColours = new Array("Blue|Circle","Red|Circle","Green|Circle","Magenta|Circle","Blue|Triangle","Red|Triangle","Green|Triangle","Magenta|Triangle","Blue|Square","Red|Square","Green|Square","Magenta|Square")
	//var theColours = new Array("Blue|Circle","Blue|Triangle","Blue|Square","Red|Circle","Red|Triangle","Red|Square","Green|Circle","Green|Triangle","Green|Square","Magenta|Circle","Magenta|Triangle","Magenta|Square")
	var theColours = new Array("Blue|Circle","Red|Circle","Green|Circle","Magenta|Circle","Orange|Circle","Cyan|Circle","Blue|Square","Red|Square","Green|Square","Magenta|Square","Orange|Square","Cyan|Square")


	// Get the position of the current variable
	var thePos = getCurrentVariable() - currentMapYearPos
	var theDetails = eval (svgMapBoundary + "_" + areaCode)
	
	// Extract the timeSeries data
	for (i=0; i < numYears; i++) {
		var theYear = eval("TIMESERIES")[i]
		var theValue = theDetails[thePos]
		
		theValues[theValues.length] = eval("TIMESERIES")[i] + "|" + theDetails[thePos]
		thePos++
	}

	var seriesDiff = timeSeriesMax - timeSeriesMin
	var seriesFactor = seriesDiff / timeSeriesHeight
	var seriesWidth  = timeSeriesWidth / numYears
	var seriesUnits =  seriesDiff/(timeSeriesHeight-timeSeriesYoffset)

	var overEvent = "showTimeSeriesDetails(evt,'L')"
	var outEvent = "hideTimeSeriesDetails(evt)"

	var thePath = "M"
	// Build the connecting line
	for (i=0; i < theValues.length; i++) {
		var theValue = theValues[i].split("|")[1]
		var seriesValue = timeSeriesYoffset+(theValue - timeSeriesMin)/seriesUnits
		var xCoord = parseInt((i*seriesWidth))
		var yCoord = parseInt((timeSeriesHeight - seriesValue))

		thePath += " " +  xCoord + "," + yCoord
		if (i==0) {
			prevX = xCoord
			prevY = yCoord
		}
	}	
	thePath += " M " + prevX + "," + prevY


	var newLine = svgChartDoc.createElement("path");
	newLine.setAttribute("d",thePath);
	newLine.setAttribute("id",areaCode);
	newLine.setAttribute("fill","none");
	newLine.setAttribute("stroke",theColours[seriesNum].split("|")[0]);
	newLine.setAttribute("stroke-width","1")
	newLine.setAttribute("onmouseover",overEvent);
	newLine.setAttribute("onmouseout",outEvent);
	targetLayer.appendChild(newLine);	

	var prevX = 0
	var prevY = 0
	
	var overEvent = "showTimeSeriesDetails(evt,'P')"
	var outEvent = "hideTimeSeriesDetails(evt)"



	for (i=0; i < theValues.length; i++) {
		var theYear = theValues[i].split("|")[0]
		var theValue = theValues[i].split("|")[1]
	
		var seriesValue = timeSeriesYoffset+(theValue - timeSeriesMin)/seriesUnits
		var theID = areaCode+"|"+theYear+"|"+theValue
	
		switch(theColours[seriesNum].split("|")[1]) {
			case "Circle" 	: 	var newCircle = svgChartDoc.createElement("circle");
								newCircle.setAttribute("cx",(i*seriesWidth));
								newCircle.setAttribute("cy",timeSeriesHeight - seriesValue);
								newCircle.setAttribute("r","2");
								newCircle.setAttribute("id",theID);
								newCircle.setAttribute("fill",theColours[seriesNum].split("|")[0]);
								newCircle.setAttribute("stroke","none");		
								newCircle.setAttribute("onmouseover",overEvent);
								newCircle.setAttribute("onmouseout",outEvent);
								targetLayer.appendChild(newCircle);
								break;
								
			case "Triangle" :   var newTriangle = svgChartDoc.createElement("path");
								var thePath = "M " + (i*seriesWidth) + "," + (timeSeriesHeight - seriesValue-2.5) + " " + (i*seriesWidth+2.5) + "," + (timeSeriesHeight - seriesValue+2.5) + " " + (i*seriesWidth-2.5) + "," + (timeSeriesHeight - seriesValue+2.5) + "z"
								newTriangle.setAttribute("d",thePath);
								newTriangle.setAttribute("id",theID);
								newTriangle.setAttribute("fill",theColours[seriesNum].split("|")[0]);
								newTriangle.setAttribute("stroke","none");		
								newTriangle.setAttribute("onmouseover",overEvent);
								newTriangle.setAttribute("onmouseout",outEvent);
								targetLayer.appendChild(newTriangle)
								break;
		
			case "Square" 	:	var newSquare = svgChartDoc.createElement("rect");
								newSquare.setAttribute("x",(i*seriesWidth)-2);
								newSquare.setAttribute("y",timeSeriesHeight - seriesValue-2);
								newSquare.setAttribute("width","4");
								newSquare.setAttribute("height","4");	
								newSquare.setAttribute("id",theID);
								newSquare.setAttribute("fill",theColours[seriesNum].split("|")[0]);
								newSquare.setAttribute("stroke","none");		
								newSquare.setAttribute("onmouseover",overEvent);
								newSquare.setAttribute("onmouseout",outEvent);
								targetLayer.appendChild(newSquare);
								break;	
		
		}
		thePos++
	}
	
}

function showTimeSeriesDetails(evt, theType) {

	var theDoc = evt.getTarget().getOwnerDocument()
	var theCode = evt.target.getAttribute("id");
	
	//alert(theCode)
	
	// Create the display for Point mouseover 
	if (theType == "P") {
		var newX = parseInt(evt.target.getAttribute("cx"));
		var newY = parseInt(evt.target.getAttribute("cy"));

		//Get the year and value
		var theText = theCode.split("|")[1] + " : " + formatValues(theCode.split("|")[2])
		var rectWidth = (theText.length * 3.5)
		
	}
		
	// Create the display for Line mouseover
	if (theType == "L") {
		var thePath = evt.target.getAttribute("d").split(" ")
			
		for (i=1; i < thePath.length; i++) {
			if (thePath[i] == "M") {
				var newX = parseInt(thePath[i-1].split(",")[0])
				var newY = parseInt(thePath[i-1].split(",")[1])
			}
		}
		
		//Get the area Name
		var theText = getAreaName(theCode)
		
		if (theText.length < 10) {
			var rectWidth = theText.length * 4
		}
		
		if ((theText.length >= 10) && (theText.length < 20)) {
			var rectWidth = (theText.length * 3.5) 
		}
		
		if ((theText.length >= 20) && (theText.length < 30)) {
			var rectWidth = (theText.length * 3.2) 
		}
		
		if (theText.length >= 30)  {
			var rectWidth = (theText.length * 3.15) 
		}		
	
	}



	svgChartDoc.getElementById('chartPopupRect').setAttribute('x',newX+45);
	svgChartDoc.getElementById('chartPopupRect').setAttribute('y',newY+3);
	svgChartDoc.getElementById('chartPopupRect').setAttribute('width',rectWidth);
	
	
	svgChartDoc.getElementById('chartPopupText').setAttribute('x',newX+47);
	svgChartDoc.getElementById('chartPopupText').setAttribute('y',newY+10);
	svgChartDoc.getElementById('chartPopupText').getFirstChild().setData(theText)
	
	
	
	svgChartDoc.getElementById('chartPopupRect').setAttribute('display','inline')
	svgChartDoc.getElementById('chartPopupText').setAttribute('display','inline')

}

function hideTimeSeriesDetails(evt) {
	svgChartDoc.getElementById('chartPopupRect').setAttribute('display','none')
	svgChartDoc.getElementById('chartPopupText').setAttribute('display','none')

}