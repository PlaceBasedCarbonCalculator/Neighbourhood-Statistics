function init(evt){
	svgdoc = evt.getTarget().getOwnerDocument();
}

function queryArea(evt){
	
	if (showHighlight == false) {
		return
	}
	
	if (thematicThesholds[0][0] > 500) {
		return
	}
	var theDoc = evt.getTarget().getOwnerDocument()
	var theCode = evt.target.getAttribute("id");
	
	areaName = getAreaName(theCode)
	areaName = areaName.replace(",","")
	
	
	// Check if the area is a "Not Applicable" area 
	if ((theDoc.getElementById(theCode).getStyle().getPropertyValue("fill")).length == 0) {
		return
	}
	
	if (evt.type == "mouseover") {
		polygonColour = theDoc.getElementById(theCode).getStyle().getPropertyValue("fill");
		
		theDoc.getElementById(theCode).getStyle().setProperty("fill",highlightColour);

		if (svgMapSize == 1) {
			var areaList = svgMapDoc.getElementById("Ork_Shet").getChildNodes()
			
			if (areaList.item(3).getAttribute("id") == theCode) {
				areaList.item(3).getStyle().setProperty('fill',highlightColour)
			}
			if (areaList.item(7).getAttribute("id") == theCode) {
				areaList.item(7).getStyle().setProperty('fill',highlightColour)
			}
		}

		highlightChart(areaName)
		hightlightTable(areaName)

		// Build the timeSeries chart if required
		if (timeSeries) {
			clearTimeSeries()
			buildTimeSeries(theCode)
		}

	}
	
	if (evt.type == "mouseout") {
		theDoc.getElementById(theCode).getStyle().setProperty('fill',polygonColour)

	if (svgMapSize == 1) {
			var areaList = svgMapDoc.getElementById("Ork_Shet").getChildNodes()
			if (areaList.item(3).getAttribute("id") == theCode) {
				areaList.item(3).getStyle().setProperty('fill',polygonColour)
			}
			
			if (areaList.item(7).getAttribute("id") == theCode) {	
				areaList.item(7).getStyle().setProperty('fill',polygonColour)
			}
		}

		
		lowlightChart(areaName)
		lowlightTable(areaName)

		// Clear the timeseries
		if (timeSeries) {
			clearTimeSeries()
		}
	
	}
}


function selectArea(evt) {

	if (currentTool != "select") {
		return
	}
	
	// Get the selected area
	var theDoc = evt.getTarget().getOwnerDocument()
	var theCode = evt.target.getAttribute("id");

	updateSelections(theCode)

}

function addCities()	{

	var targetLayer = svgMapDoc.getElementById("cities");
	var cityList = eval(CITYList)
	
	alert(cityList.length)
		
	var theValue = 	svgMapDoc.getElementById(svgMapBoundary).getAttribute('transform');
	
	var startPos = theValue.indexOf(",")
	var endPos = theValue.indexOf(")")
	var yOffset = theValue.substring(startPos+1,endPos)
	if (yOffset < 0) {
		yOffset = yOffset*-1
	}
		
	for (i=0;i<cityList.length;i++)	{
		var cityName = eval(cityList)[i].split("|")[0]
		var cityX = eval(cityList)[i].split("|")[1]
		var cityY = eval(cityList)[i].split("|")[2]
		
		var textX = cityX
		var textY = (yOffset-cityY)		

		var newCircle = svgMapDoc.createElement("circle");
		newCircle.setAttribute("cx",cityX);
		newCircle.setAttribute("cy",cityY);
		newCircle.setAttribute("r","1000");
		newCircle.setAttribute("id","city"+i);		
		newCircle.setAttribute("fill","black");
		newCircle.setAttribute("stroke","black");
		newCircle.setAttribute("stroke-width","0.5%");
		newCircle.setAttribute("opacity","0.5");
		

		var newText = svgMapDoc.createElement("text");
		newText.setAttribute("x",textX);
		newText.setAttribute("y",textY);
		newText.setAttribute("id","cityText"+i);
		var theValue = 'translate(1500,' + yOffset + ') scale(1, -1)';
		newText.setAttribute('transform', theValue);
		var css = newText.getStyle();
		css.setProperty("fill","black");
		css.setProperty("stroke","white");
		css.setProperty("font-weight","bold");
	    css.setProperty("stroke-width","0.05");
		css.setProperty("font-size","5000");
		
		var CityText = svgMapDoc.createTextNode(cityName);
		newText.appendChild(CityText);

		targetLayer.appendChild(newCircle);
		targetLayer.appendChild(newText);
	}

}

//highlights text in menu
function HighLightText(evt)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var theText = evt.target.getAttribute("id");
	theDoc.getElementById(theText).setAttribute('text-decoration','underline');
	theDoc.getElementById(theText).setAttribute('font-weight','bold');
}

function LowLightText(evt, value)	{
	var theDoc = evt.getTarget().getOwnerDocument()
	var theText = evt.target.getAttribute("id");
	theDoc.getElementById(theText).setAttribute('text-decoration','none');
	theDoc.getElementById(theText).setAttribute('font-weight','normal');
}


// reset order to numeric
function numberOrder(a,b) { 
	return a - b; 
}

function alphaAscending(aValue1, aValue2) {
     if (aValue1 > aValue2) {
     	return (-1)
     } else {
     	return (1)
     }
}

function alphaDescending(aValue1, aValue2) {
     if (aValue1 > aValue2) {
     	return (1)
     } else {
     	return (-1)
     }
}

function numberDescending(a,b) { 
	var aValue = a.split("|")[1]
	var bValue = b.split("|")[1]
	
	return aValue - bValue; 
}

function numberAscending(a,b) { 
	var aValue = a.split("|")[1]
	var bValue = b.split("|")[1]
	
	return bValue - aValue; 
}

function onsSort(a,b) { 
	var aValue = a.split("|")[2]
	var bValue = b.split("|")[2]
	
	return aValue - bValue

}


function laSort(a,b) { 
	var aValue = a.split("|")[2]
	var bValue = b.split("|")[2]
	
     if (aValue > bValue) {
     	return (1)
     } else {
     	return (-1)
     }
}


function setDecimals(inString) {

	// Check that the value is a number
	if (isNaN(inString)) {
		return inString
	}

	//Check if there is a decimal point
	if (inString.indexOf(".") == -1) {
		numDecimals = 0
	} else {
		var theString = inString.split(".")[0]
		numDecimals = theString.length
	}
}

// Formats the string by adding the "thousands commas" 
function formatValues(inString) {

	// Check that the value is a number
	if (isNaN(inString)) {
		return inString
	}

	//Check if there is a decimal point
	if (inString.indexOf(".") == -1) {
		var gotDecimal = false
		var theString = inString
	} else {
		var gotDecimal = true
		var theString = inString.split(".")[0]
	}
	var theLength = theString.length
		
	switch (theLength) {
			
		case 4 : var fmtString = theString.substring(0,1) + "," + theString.substring(theLength-3)
				 break;
		case 5 : var fmtString = theString.substring(0,2) + "," + theString.substring(theLength-3)
				 break;			
		case 6 : var fmtString = theString.substring(0,3) + "," + theString.substring(theLength-3)
				 break;			
		case 7 : var fmtString = theString.substring(0,1) + "," + theString.substring(1,4)+ "," + theString.substr(theLength-3)
				 break;							 
		case 8 : var fmtString = theString.substring(0,2) + "," + theString.substring(2,5)+ "," + theString.substr(theLength-3)
				 break;	
		case 9 : var fmtString = theString.substring(0,3) + "," + theString.substring(3,6)+ "," + theString.substr(theLength-3)
				 break;					
		default : var fmtString = theString
	}

	// Append back the decimal if required
	if (gotDecimal) {
		
		var tmpString = inString.split(".")[1]
	
		//fmtString += "." + inString.split(".")[1]
		fmtString += "." + tmpString.substr(0,numDecimals)
		
		
		//Check that the "zero" decimals haven't been dropped
		var tmpValue = fmtString.toString().split(".")[1]
		var theDiff =  numDecimals - tmpValue.length
				
		if (theDiff != 0) {	
			for (i=0; i <theDiff;i++) {
			
				fmtString += "0"
			}
		}
	}
	
	return fmtString	
}


function getAreaName(theCode) {

	switch (svgMapBoundary) {
	
		case "WARD" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)
						break;
		case "MSOA" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)	
						break;
		case "LSOA" :	var theList = svgMapBoundary+'List_' + 	svgMapArea
						break;
		default : 		var theList = svgMapBoundary+'List'
	}
			
	for (i=0; i < eval(theList).length;i++) {
		var areaCode = eval(theList)[i].split("|")[1]
		var areaName = eval(theList)[i].split("|")[2]
		if (areaCode == theCode) {
			break
		}
	}
	return areaName
}

function getAreaCode(areaName) {

	if (areaName.indexOf("..") > -1) {
		var isShortened = true
		areaName = areaName.replace("..","")
	} else {
		var isShortened = false	
	}

	switch (svgMapBoundary) {
	
		case "WARD" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)
						break;
		case "MSOA" : 	var theList = svgMapBoundary+'List_' + 	getLARegion(svgMapArea)	
						break;
		case "LSOA" :	var theList = svgMapBoundary+'List_' + 	svgMapArea
						break;
		default : 		var theList = svgMapBoundary+'List'
	}

	for (i=0; i < eval(theList).length;i++) {
		var theCode = eval(theList)[i].split("|")[1]
		var theName = eval(theList)[i].split("|")[2]
		
		//Remove any commas
		theName = theName.replace(",","")

		// Check if the name has been shortened
		if (isShortened) {
			if (theName.indexOf(areaName) > -1) {
				break
			}
		} else {
			if (theName == areaName) {
				break
			}
		}
	}
	return theCode
}



function getCurrentVariable() {
	var theVariables = eval("TIMESERIES")
	var numYearVars = theVariables.length
	if (numYearVars == 0) {
		numYearVars = 1
	}

	var topicPos = (currentMapTopicPos*currentMapTopicPage)
	var yearPos = (currentMapYearPos*currentMapYearPage)
	
	currentVariable = (topicPos*numYearVars) + yearPos
		
	return (currentVariable)
}


function getGORcode(laCode) {

	for (i=0; i < eval(LAList).length;i++) {
		var theCode = eval(LAList)[i].split("|")[1]
		var gorCode = eval(LAList)[i].split("|")[3]
		if (theCode == laCode) {
			break
		}
	}
	return gorCode
}

function getLAName(laCode) {

	for (i=0; i < eval(LAList).length;i++) {
		var theCode = eval(LAList)[i].split("|")[1]
		var theName = eval(LAList)[i].split("|")[2]
		if (theCode == laCode) {
			break
		}
	}
	return theName
}

function getLARegion(laCode) {

	for (i=0; i < eval(LAList).length;i++) {
		var theCode = eval(LAList)[i].split("|")[1]
		var theRegion = eval(LAList)[i].split("|")[3]
		if (theCode == laCode) {
			break
		}
	}
	return theRegion
}



function getAxisValue(theValue) {

	if (theValue < 200) {
		newValue = parseInt(theValue/10)*10
	} else {
		newValue = parseInt(theValue/100)*100
	}
	return newValue
}

function toggleToolBar(evt) {
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('hideToolBar').getAttribute('display')
	
	if (currStatus == "none") {	
		theDoc.getElementById('hideToolBar').setAttribute('display','inline');
		theDoc.getElementById('showToolBar').setAttribute('display','none');
	} else {
		theDoc.getElementById('hideToolBar').setAttribute('display','none');
		theDoc.getElementById('showToolBar').setAttribute('display','inline');	
	}
}


function toggleInsetMap(evt) {
	var theDoc = evt.getTarget().getOwnerDocument()
	var currStatus = theDoc.getElementById('hideInsetMap').getAttribute('display')
	
	if (currStatus == "none") {	
		theDoc.getElementById('hideInsetMap').setAttribute('display','inline');
		theDoc.getElementById('showInsetMap').setAttribute('display','none');
	} else {
		theDoc.getElementById('hideInsetMap').setAttribute('display','none');
		theDoc.getElementById('showInsetMap').setAttribute('display','inline');	
	}
}


function selectTool(theTool) {

	// If the Select tool is unselected then clear any highlighting
	if (svgMapDoc.getElementById('selectArrow').getStyle().getPropertyValue("fill")=='red') {
		resetTools() 
		currentSelections = ""
		colourMap()
		clearTimeSeries()

		//Build the bar chart (either "normal" or "index" bar chart
		var theTypes = eval(TYPEDESC)
		var typeDetails = theTypes[currentMapTopicPos*currentMapTopicPage]
		var varUnits = typeDetails.split("|")[1]
		
		if (varUnits.indexOf("Extra-Regio=100") == -1) {
			buildBarChart()
		} else {
			buildIndexBarChart()
		}

		clearDataTable()
		return
	}
	
	//Reset all the tools
	resetTools()
	showHighlight = false

	// Get the current map extent
	var mapWin = svgMapDoc.getElementById('Map');
	var currMinX = mapWin.getAttribute('viewBox').split(" ")[0]
	var currMinY = mapWin.getAttribute('viewBox').split(" ")[1]
	var currWidth = mapWin.getAttribute('viewBox').split(" ")[2]
	var currHeight = mapWin.getAttribute('viewBox').split(" ")[3]
	
	currentTool = theTool
	
	// Activate the tool
	switch (theTool) {
		
		case "zoomIn" : mapXcoord=0
						mapYcoord=0	
						svgMapDoc.getElementById('zoomIn').setAttribute('class','activeTool')
						break;
		
		case "zoomOut" : mapXcoord=0
						 mapYcoord=0
						 svgMapDoc.getElementById('zoomOut').setAttribute('class','activeTool')
						 break;
		
		case "fullMap" : mapXcoord=0
						 mapYcoord=0
		  				 svgMapDoc.getElementById('fullMap').setAttribute('class','activeTool')
						 var mapWin = svgMapDoc.getElementById('Map')
						 mapWin.setAttribute('viewBox',fullExtent[0]+" "+fullExtent[1]+" "+fullExtent[2]+" "+fullExtent[3]);
						 
						 //Reset all the tools
						 resetTools()
						 break;
						
		case "panMap" :  svgMapDoc.getElementById('panMap').getStyle().setProperty('fill','red')
						 break;
	
		case "select" :  svgMapDoc.getElementById('selectArrow').getStyle().setProperty('fill','red')
						 break;
	
	}
}


function getMapPos(evt) {


	var screenX = evt.getClientX
	var screenY = evt.getClientY
	
	var currMinX = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[0])
	var currMinY = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[1])
	var currWidth = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[2])
	var currHeight = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[3])

	var pixWidth = parseFloat(svgMapDoc.getElementById('MainSVG').getAttribute("width")); 
	var pixSize = currWidth / pixWidth;

	var mapX = currMinX + parseInt(Math.abs(screenX*pixSize))
	var mapY = currMinY + parseInt(Math.abs(screenY*pixSize))
	
	
	if (currentTool == "zoomIn") {
		newWidth = parseInt(currWidth*0.80)
		newHeight = parseInt(currHeight*0.80)

		newXcoord = parseInt(mapX-newWidth*0.5)		
		newYcoord = parseInt(mapY-newHeight*0.5)

		svgMapDoc.getElementById('Map').setAttribute('viewBox', newXcoord +  " " + newYcoord + " " + newWidth+" "+newHeight);		
	}

	if (currentTool == "zoomOut") {
		newWidth = parseInt(currWidth*1.2)
		newHeight = parseInt(currHeight*1.2)
		
		if (newWidth >= fullExtent[2]) {
			alert("You can't zoom out beyond the original map extent")
			currentTool = ""
			svgMapDoc.getElementById('zoomOut').setAttribute('class','inactiveTool')
			svgMapDoc.getElementById('Map').setAttribute('viewBox',fullExtent[0]+" "+fullExtent[1]+" "+fullExtent[2]+" "+fullExtent[3])
		} else {
			newXcoord = parseInt(mapX-newWidth*0.5)		
			newYcoord = parseInt(mapY-newHeight*0.5)
			svgMapDoc.getElementById('Map').setAttribute('viewBox',newXcoord+" "+newYcoord+" "+newWidth+" "+newHeight);
		}
	}

	if (currentTool != "select") {
		//Reset all the tools
		resetTools()

		// Refresh the Map
		colourMap()
	}
}	
	
function startPan(evt) {
	if (currentTool == "panMap") {
		var screenX = evt.getClientX
		var screenY = evt.getClientY
	
		var currMinX = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[0])
		var currMinY = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[1])
		var currWidth = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[2])
		var currHeight = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[3])

		var pixWidth = parseFloat(svgMapDoc.getElementById('MainSVG').getAttribute("width")); 
		var pixSize = currWidth / pixWidth;

		var mapX = currMinX + parseInt(Math.abs(screenX*pixSize))
		var mapY = currMinY + parseInt(Math.abs(screenY*pixSize))

		mapXcoord = mapX
		mapYcoord = mapY
	}	
}
	

function moveMap(evt) {

	if (currentTool == "panMap") {
	
		var screenX = evt.getClientX
		var screenY = evt.getClientY
		
		var currMinX = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[0])
		var currMinY = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[1])
		var currWidth = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[2])
		var currHeight = parseInt(svgMapDoc.getElementById('Map').getAttribute('viewBox').split(" ")[3])
	
		var pixWidth = parseFloat(svgMapDoc.getElementById('MainSVG').getAttribute("width")); 
		var pixSize = currWidth / pixWidth;
	
		
		var mapX = currMinX + parseInt(Math.abs(screenX*pixSize))
		var mapY = currMinY + parseInt(Math.abs(screenY*pixSize))
	
	
		if ((mapXcoord != 0) && (mapYcoord != 0)) {
			var changeX = mapXcoord - mapX 
			var changeY = mapYcoord - mapY
			newXcoord = currMinX + changeX
			newYcoord = currMinY + changeY
			svgMapDoc.getElementById('Map').setAttribute('viewBox',newXcoord+" "+newYcoord+" "+currWidth+" "+currHeight);
		}
	
	}
}

function stopPan(evt) {
	if (currentTool == "panMap") {
		mapXcoord = 0
		mapYcoord = 0
	
		resetTools()

	}	
}

function resetTools() {
	//Reset all the tools
	svgMapDoc.getElementById('zoomIn').setAttribute('class','inactiveTool')
	svgMapDoc.getElementById('zoomOut').setAttribute('class','inactiveTool')
	svgMapDoc.getElementById('fullMap').setAttribute('class','inactiveTool')
	svgMapDoc.getElementById('panMap').getStyle().setProperty('fill','black')
	svgMapDoc.getElementById('selectArrow').getStyle().setProperty('fill','black')
	
	currentTool = ""
	showHighlight = true
	clearDataTable()
	currentSelections = ""
}


function updateSelections (theCode) {
	
	// Check if the code already exists in the list
	if (currentSelections.indexOf(theCode) == -1) {	
		//Check the number of selected areas
		if (currentSelections.split("|").length > 23) {
			alert("You can have a maximum of 12 areas selected at one time. Please\nunselect some areas before continuing.") 
			return
		}
		var theColour = svgMapDoc.getElementById(theCode).getStyle().getPropertyValue("fill");
	
		if (currentSelections.length == 0) {
			currentSelections = theCode + "|" + theColour
		} else {
			currentSelections += "|" + theCode + "|" + theColour
		}
	} else {
	//Remove the code from the list
		var theDetails = currentSelections.split("|")
		currentSelections = ""
			
		for (var i=0;i < theDetails.length-1;i++)	{
			var areaCode = theDetails[i]
			var areaColour = theDetails[i+1]

			if (areaCode == theCode) {
				var areaName = getAreaName(areaCode)
				areaName = areaName.replace("..","")
				areaName = areaName.replace(",","")
				svgMapDoc.getElementById(areaCode).getStyle().setProperty('fill',areaColour)

				if (svgMapSize == 1) {

				//if ((svgMapBoundary == "CTRY") || (svgMapBoundary == "LA") ||  (svgMapBoundary.indexOf("NUTS") > -1)) {
					var areaList = svgMapDoc.getElementById("Ork_Shet").getChildNodes()
					if (areaList.item(3).getAttribute("id") == theCode) {
						areaList.item(3).getStyle().setProperty('fill',areaColour)
					}
					if (areaList.item(7).getAttribute("id") == theCode) {			
						areaList.item(7).getStyle().setProperty('fill',areaColour)
					}
				}

				lowlightChart(areaName)
				lowlightTable(areaName)		
			} else {
				if (currentSelections.length == 0) {
					currentSelections = areaCode + "|" + areaColour
				} else {
					currentSelections += "|" + areaCode + "|" + areaColour
				}
			}
			i++
		}
	}
		
	if (timeSeries) {
		clearTimeSeries()
	}

	if (currentSelections.length == 0) {
		return
	}	
	
	// Highlight the areas in the list
	theDetails = currentSelections.split("|")
	
	for (var i=0;i < theDetails.length;i++)	{
		var areaCode = theDetails[i]
		
		areaName = getAreaName(areaCode)
		areaName = areaName.replace("..","")
		areaName = areaName.replace(",","")
		
		highlightMap(areaName)
		highlightChart(areaName)
		hightlightTable(areaName)
		if (timeSeries) {
			buildMultiTimeSeries(areaCode, i) 
		}
		i++
	}
}
