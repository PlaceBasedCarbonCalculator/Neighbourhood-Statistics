function overStyle (theFeature) {
	theFeature.style.cursor='hand';
}

function loadAreas(theArea) {

	document.forms[0].mapArea.options.length = 0;
	document.forms[0].mapArea.options[0] = new Option("Choose one :","0",false,false)


	switch (theArea) {
		case "CTRY" : 	var aList = CTRYList
										break;
		case "GOR" 	: 	var aList = GORList
										break;
		case "LA"	:	var aList = LAList
						aList.sort(laSort)
						break;
	}

	for (i=0; i < aList.length; i++) {
		var aCode = aList[i].split("|")[1]
		var aName = aList[i].split("|")[2]
		document.forms[0].mapArea.options[i+1] = new Option(aName,aCode,false,false)
	}

	// Activate the drop-down list
	document.forms[0].mapArea.disabled = false
}

function clickMapSize(theValue) {

	document.forms[0].svgMapSize.value = theValue
	document.forms[0].mapBoundary.options.length = 0;
	document.forms[0].mapBoundary.options[0] = new Option("Choose one :","0",false,false)

	document.forms[0].mapData.options.length = 0;
	document.forms[0].mapData.options[0] = new Option("","0",false,false)
	document.forms[0].mapData.disabled = true

	switch (theValue) {

		case "0" :  // Reset all the hidden fields
					document.forms[0].svgMapSize.value = ""
					document.forms[0].svgMapArea.value = ""
					document.forms[0].svgMapBoundary.value = ""
					document.forms[0].svgMapData.value = ""
					document.forms[0].svgCustomDataset.value = ""

					// Reset all the lists
					document.forms[0].mapArea.options.length = 0;
					document.forms[0].mapArea.options[0] = new Option("","0",false,false)
					document.forms[0].mapArea.disabled = true

					document.forms[0].mapBoundary.options.length = 0;
					document.forms[0].mapBoundary.options[0] = new Option("","0",false,false)
					document.forms[0].mapBoundary.disabled = true

					document.forms[0].mapData.options.length = 0;
					document.forms[0].mapData.options[0] = new Option("","0",false,false)
					document.forms[0].mapData.disabled = true
					break;

		case "1" :	document.forms[0].mapArea.options.length = 0;
					document.forms[0].mapArea.options[0] = new Option("Not Applicable","0",false,false)
					document.forms[0].mapArea.disabled = true

					document.forms[0].mapBoundary.options[0] = new Option("Choose one :","0",false,false)
					document.forms[0].mapBoundary.options[1] = new Option("Country","CTRY",false,false)
					document.forms[0].mapBoundary.options[2] = new Option("NUTS level1","NUTS1",false,false)
					document.forms[0].mapBoundary.options[3] = new Option("NUTS level2","NUTS2",false,false)
					document.forms[0].mapBoundary.options[4] = new Option("NUTS level3","NUTS3",false,false)
					document.forms[0].mapBoundary.options[5] = new Option("Local Authority","LA",false,false)
					document.forms[0].mapBoundary.options[6] = new Option("Education Authority","EA",false,false)
				 	document.forms[0].mapBoundary.disabled = false
					document.forms[0].mapBoundary.focus()
					break;

		case "2" :	loadAreas("CTRY")
	 				document.forms[0].mapBoundary.options.length = 0;
					document.forms[0].mapBoundary.options[0] = new Option("","0",false,false)
					document.forms[0].mapBoundary.disabled = true
	 				break;

		case "3" :	loadAreas("GOR")
	 				document.forms[0].mapBoundary.options.length = 0;
					document.forms[0].mapBoundary.options[0] = new Option("","0",false,false)
					document.forms[0].mapBoundary.disabled = true
	 				break;

		case "4" :	loadAreas("LA")
					document.forms[0].mapBoundary.options.length = 0;
					document.forms[0].mapBoundary.options[0] = new Option("","0",false,false)
					document.forms[0].mapBoundary.disabled = true
					break;

	}
}


function clickMapArea() {

	var theValue = document.forms[0].mapSize.value
	var mapArea = document.forms[0].mapArea.value

	document.forms[0].svgMapArea.value = mapArea
	document.forms[0].mapBoundary.options.length = 0;
	document.forms[0].mapBoundary.options[0] = new Option("Choose one :","0",false,false)

	document.forms[0].mapData.options.length = 0;
	document.forms[0].mapData.options[0] = new Option("","0",false,false)
	document.forms[0].mapData.disabled = true

	switch (theValue) {

		case "0" :	document.forms[0].mapBoundary.options.length = 0;
					document.forms[0].mapBoundary.options[0] = new Option("","0",false,false)
					document.forms[0].mapBoundary.disabled = true
					break;

		case "1" :	document.forms[0].mapBoundary.options[1] = new Option("Local Authority","LA",false,false)
					document.forms[0].mapBoundary.options[2] = new Option("Ward","WARD",false,false)
				 	document.forms[0].mapBoundary.disabled = false
				 	break;

		case "2" :
					//England
					if (document.forms[0].mapArea.value == "064") {
						document.forms[0].mapBoundary.options[1] = new Option("Region","GOR",false,false)
						document.forms[0].mapBoundary.options[2] = new Option("County","CTY",false,false)
						document.forms[0].mapBoundary.options[3] = new Option("Local Authority","LA",false,false)
						document.forms[0].mapBoundary.options[4] = new Option("Strategic Health Authority","SHA",false,false)
						document.forms[0].mapBoundary.options[5] = new Option("Education Authority","EA",false,false)
					}

					// Wales
					if (document.forms[0].mapArea.value == "220") {
						document.forms[0].mapBoundary.options[1] = new Option("Local Authority","LA",false,false)
						document.forms[0].mapBoundary.options[2] = new Option("Primary Care Organisation","PCO",false,false)
						document.forms[0].mapBoundary.options[3] = new Option("Education Authority","EA",false,false)
					}

					//Scotland
					if (document.forms[0].mapArea.value == "179") {
						document.forms[0].mapBoundary.options[1] = new Option("Local Authority","LA",false,false)
						document.forms[0].mapBoundary.options[2] = new Option("Primary Care Organisation","PCO",false,false)
						document.forms[0].mapBoundary.options[3] = new Option("Education Authority","EA",false,false)
					}

					// Northern Ireland
					if (document.forms[0].mapArea.value == "152") {
						document.forms[0].mapBoundary.options[1] = new Option("Local Authority","LA",false,false)
						document.forms[0].mapBoundary.options[2] = new Option("Primary Care Organisation","PCO",false,false)
						document.forms[0].mapBoundary.options[3] = new Option("Education Authority","EA",false,false)
					}
				 	document.forms[0].mapBoundary.disabled = false
				 	break;

		case "3" :	document.forms[0].mapBoundary.options[1] = new Option("Local Authority","LA",false,false)
					document.forms[0].mapBoundary.options[2] = new Option("Ward","WARD",false,false)
					document.forms[0].mapBoundary.options[3] = new Option("Middle Layer SOA","MSOA",false,false)
					document.forms[0].mapBoundary.options[4] = new Option("Lower Layer SOA","LSOA",false,false)
					document.forms[0].mapBoundary.options[5] = new Option("Primary Care Organisation","PCO",false,false)
					document.forms[0].mapBoundary.options[6] = new Option("Education Authority","EA",false,false)
				 	document.forms[0].mapBoundary.disabled = false
					break;

		case "4" :	document.forms[0].mapBoundary.options[1] = new Option("Ward","WARD",false,false)
					document.forms[0].mapBoundary.options[2] = new Option("Middle Layer SOA","MSOA",false,false)
					document.forms[0].mapBoundary.options[3] = new Option("Lower Layer SOA","LSOA",false,false)
				 	document.forms[0].mapBoundary.disabled = false
				 	break;
	}
}

function clickMapData() {

	var theValue = parseInt(document.forms[0].mapData.value)
	document.forms[0].svgMapData.value = theValue


	//if ((theValue == 100) || (theValue == 200) || (theValue == 300) || (theValue == 400)) {
	//	document.forms[0].customDataset.style.backgroundColor='white'
	//	document.forms[0].customDataset.style.borderStyle = 'solid'
	//	document.forms[0].customDataText.style.color = '#000066'
	//	document.forms[0].customDataset.focus()
	//} else {
	//	document.forms[0].customDataset.style.backgroundColor='ccccff'
	//	document.forms[0].customDataset.value = ""
	//	document.forms[0].customDataset.style.borderStyle = 'solid'
	//	document.forms[0].customDataText.style.color = '#ccccff'
	//}

	//var customData = document.forms[0].customDataset.value
	//document.forms[0].svgCustomDataset.value = customData
}

function laSort(a,b) { 
	var aValue = a.split("|")[2]
	var bValue = b.split("|")[2]
	
     if (aValue > bValue) {
     	return (1)
     } else {
     	return (-1)
     }
}