function buildLegend()  {

	var theTypes = eval(TYPEDESC)
	var theDetails = eval(SHORTDESC)
	var numVars = theDetails.length
	thePos = currentMapTopicPos*currentMapTopicPage
	var theHeading = theDetails[thePos]
	
	// Get the heading from the "short" description array
	var theStatus = svgThematicDoc.getElementById('yearDropDown').getAttribute('display')
	
	if (theStatus == "inline") {
		var theTopic = currentMapTopicPos*currentMapTopicPage
		var theSeries = eval(TIMESERIES)				
		var theYear = theSeries[currentMapYearPos*currentMapYearPage]
		theHeading += " (" + theYear + ")"
	}
	
	
	var tmpChar
	var startPos = 0
	var endPos = 35
	var descLength = theHeading.length
	
	for (x=1; x < 3; x++) {	
		if ((endPos > descLength) || (startPos >= descLength)){
			endPos = descLength
			theChar = " "
		} else {
			theChar = theHeading.substr(endPos,1)
		}
		var i = 0
		if (theChar != " ") {
			for (i=1; i < 35; i++) {
				tmpChar = theHeading.substr((endPos-i),1)
				if (tmpChar == " ") {
					thePos = i
					i = 36
				}
			}
			endPos = endPos - thePos
		}
		svgDataDoc.getElementById('legendHeading'+x).getFirstChild().setData(theHeading.substring(startPos,endPos))
		svgDataDoc.getElementById('legendHeading'+x).setAttribute('display','inline')
		startPos = endPos + 1
		endPos = startPos + 35
	}
		
	// Get the sub-heading from the "type" description array
	var typeDetails = theTypes[currentMapTopicPos*currentMapTopicPage]
	var varType = typeDetails.split("|")[0]
	var varUnits = typeDetails.split("|")[1]

	switch (varType) {

		//case "Number"  	:	var subHeading = varType 
		//					
		//					if (varUnits.length > 0) {
		//						subHeading += " (" + varUnits + ")"
		//					}
		//					break;
		//
		//case "Index"  	:	var subHeading = varType + " (" + varUnits + ")" 
		//					if (varUnits.length > 0) {
		//						subHeading += " (" + varUnits + ")"
		//					}
		//					break;
//
		//case "Value"  	:	var subHeading = varType + " (" + varUnits + ")" 
		//					if (varUnits.length > 0) {
		//						subHeading += " (" + varUnits + ")"
		//					}
		//					break;
		//				
		case "Rank"		:	
							if (svgMapBoundary == "LSOA") {
								var subHeading = "Rank of 34,378 Lower SOA's in England"

							} else {
								var subHeading = "Rank of 354 Local Authorities in England"
							}
							break;
							
		default :			var subHeading = varType 
							if (varUnits.length > 0) {
									subHeading += " (" + varUnits + ")"
							}
							break;
	}
	
	
	svgDataDoc.getElementById('legendCategoryHeading').getFirstChild().setData(subHeading)
	svgDataDoc.getElementById('legendCategoryHeading').setAttribute('display','inline')



	// Display the necessary categories
	var i=1
	for (x=1; x <=mapColours.length ; x++) {
		svgDataDoc.getElementById('legendCategory'+x).setAttribute('display','none')
		svgDataDoc.getElementById('legendCategoryText'+x).setAttribute('display','none')		
	}

	for (x=currentNumColours; x > 0; x--) {
		theShade = thematicThesholds[x][0]
		minValue = thematicThesholds[x][1]
		maxValue = thematicThesholds[x][2]
			
		// Add the ONS standard text to the first/last gradation
		if (i == currentNumColours) {
			var theText = formatValues(maxValue.toString()) + " or under"
		} else if (i == 1) {
			minValue = minValue + (1/Math.pow(10,numDecimals))
			var theText = formatValues(minValue.toString()) + " or over"
		} else {
			minValue = minValue + (1/Math.pow(10,numDecimals))
			
			var theText = formatValues(minValue.toString()) + " - " + formatValues(maxValue.toString())
		}
						

		//var theText = "Ranks " + minValue + " to " + maxValue
		
		svgDataDoc.getElementById('legendCategory'+i).getStyle().setProperty('fill',theShade)
		svgDataDoc.getElementById('legendCategoryText'+i).getFirstChild().setData(theText)		
		
		svgDataDoc.getElementById('legendCategory'+i).setAttribute('display','inline')
		svgDataDoc.getElementById('legendCategoryText'+i).setAttribute('display','inline')
	
		i++
	}

	// Add the not available 	
	if (hasNotAvailable) {
		svgDataDoc.getElementById('legendCategory'+i).getStyle().setProperty('fill',notAvailableColour)
		svgDataDoc.getElementById('legendCategoryText'+i).getFirstChild().setData('Not Available')		
		svgDataDoc.getElementById('legendCategory'+i).setAttribute('display','inline')
		svgDataDoc.getElementById('legendCategoryText'+i).setAttribute('display','inline')
	}
	
	if (svgDataDoc.getElementById('legendHeading2').getFirstChild().getData.length ==0) {
		var theValue = 'translate(0 8)';
		svgDataDoc.getElementById('legendCategories').setAttribute('transform',theValue);
	} else {
		var theValue = 'translate(0 18)';
		svgDataDoc.getElementById('legendCategories').setAttribute('transform',theValue);
	
	}
	
}


function initDataTable() {
	
	// Set the length of the data table and scrollbar
	var numVars = currentDetails.length
	if (numVars > dataRows) {
		numVars = dataRows
	}
	
	var theSize = 15*numVars + 15
	svgDataDoc.getElementById('dataTableRect').setAttribute('height',theSize);
	svgDataDoc.getElementById('sliderRect').setAttribute('height',numVars*15);

	theValue = 'translate(0 ' + (theSize - 15) + ')';
	svgDataDoc.getElementById('downArrow').setAttribute('transform', theValue);
	
	if (numVars < dataRows) {
		svgDataDoc.getElementById('sliderBox').setAttribute('display','none')
	}
	
	//Display the table
	svgDataDoc.getElementById('dataTable').setAttribute('display','inline')
}


function buildDataTable() { 

	// First sort the list in required order
	currentDetails.sort(eval(dataSortOrder))
	
	
	// Clear any highlighting from the table
	if (currentSelections.length > 0) {
		clearDataTable()
	}
	
	
	if (currentDetails.length < dataRows) {
		var startPos = 0
	} else {
		var startPos = dataStartPos - dataRows
	}

	var endPos = currentDetails.length
	if (endPos > (dataRows-1)) {
		endPos = dataRows
	}
		
	// Loop through the list and update the table
	for (var i=1; i <= endPos ;i++) {
		theName = currentDetails[startPos].split("|")[0]
		if (theName.length > 20) {
			var tmpName = theName.substr(0,20) + ".."
			theName = tmpName
		}
		theValue = currentDetails[startPos].split("|")[1]	
		svgDataDoc.getElementById('r'+ (i) + "c1").getFirstChild().setData(theName)
		svgDataDoc.getElementById('r'+ (i) + "c2").getFirstChild().setData(formatValues(theValue.toString()))
		svgDataDoc.getElementById('rect'+(i)).setAttribute('display','inline')
	
		// Highlight row if the area has been selected
		if (currentSelections.length > 0) {
			areaName = theName.replace(",","")
			var theCode = getAreaCode(areaName)
						
			if (currentSelections.indexOf(theCode) > -1) {
				svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("fill",highlightColour);
				svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("opacity",1);
			}
		}		
		startPos++
	}
	
	
}


function hightlightTable(areaName) {

	// Highlight the area on the data table
	for (var i=1; i <= dataRows ;i++) {
		var theName = svgDataDoc.getElementById('r'+ (i) + "c1").getFirstChild().getData()
		
		// Check if the name has been shortened
		if (theName.indexOf("..") > -1) {
			theName = theName.replace("..","")
			theName = theName.replace(",","")
			
			if (areaName.indexOf(theName) > -1) {
				break
			}
		} else {
			if (theName == areaName) {
				break
			}
		}
	}

	if (i < 25) {
		svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("fill",highlightColour);
		svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("opacity",1);
	}
}

function lowlightTable(areaName) {

	// Highlight the area on the data table
	for (var i=1; i < 25 ;i++) {
		var theName = svgDataDoc.getElementById('r'+ (i) + "c1").getFirstChild().getData()
	
		// Check if the name has been shortened
		if (theName.indexOf("..") > -1) {
			theName = theName.replace("..","")
			theName = theName.replace(",","")
			if (areaName.indexOf(theName) > -1) {
				break
			}
		} else {
			if (theName == areaName) {
				break
			}
		}
	}

	// Check if the row is odd or even
	if (i < 25) {
		var tmpValue = (i/2).toString()
	
		if (tmpValue.indexOf(".") > 0) {
			// Odd rows 
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("fill",tableColour);
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("opacity",0.2);
		} else {
			// Even rows
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("fill","white");
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("opacity",1);
		}
	}	
}

function clearDataTable() {
	// Check if the row is odd or even
	for (var i=1; i < 25; i++) {
	
		var tmpValue = (i/2).toString()
		if (tmpValue.indexOf(".") > 0) {
			// Odd rows 
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("fill",tableColour);
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("opacity",0.2);
		} else {
			// Even rows
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("fill","white");
			svgDataDoc.getElementById("r"+i+"back").getStyle().setProperty("opacity",1);
		}
	}	
}

function queryTable(evt,theID){

	if (currentTool == "select") {
		return
	}

	var theName = svgDataDoc.getElementById(theID + "c1").getFirstChild().getData()
	theName = theName.replace(",","")
	theCode = getAreaCode(theName)

	if (evt.type == "mouseover") {
		tableColour = svgDataDoc.getElementById(theID+"back").getStyle().getPropertyValue("fill");
		svgDataDoc.getElementById(theID+"back").getStyle().setProperty("fill",highlightColour);
		svgDataDoc.getElementById(theID+"back").getStyle().setProperty("opacity",1);

		highlightMap(theName)
		highlightChart(theName)
	
		// Build the timeSeries chart if required
		if (timeSeries) {
			areaCode = getAreaCode(theName)
			clearTimeSeries()
			buildTimeSeries(areaCode)
		}

	}
	
	if (evt.type == "mouseout") {
		svgDataDoc.getElementById(theID+"back").getStyle().setProperty('fill',tableColour)
		svgDataDoc.getElementById(theID+"back").getStyle().setProperty("opacity",0.2);

		lowlightMap(theName)
		lowlightChart(theName)
		
		// Clear the timeseries
		if (timeSeries) {
			clearTimeSeries()
		}	
	}

}

function selectTable(evt) {

	if (currentTool != "select") {
		return
	}
	
	// Get the selected area
	var theDoc = evt.getTarget().getOwnerDocument()
	var theID = evt.target.getAttribute("id");
	var thePos = theID.indexOf("back")
	
	theID = theID.substr(0,thePos)
	var theName = theDoc.getElementById(theID + "c1").getFirstChild().getData()
	
	theName = theName.replace(",","")
	
	var theCode = getAreaCode(theName)
	updateSelections(theCode)
}

